import numpy as np

def detect_apnea(emg_signal, threshold=0.2):
    """
    Détecte l'apnée à partir du signal EMG.
    Si la moyenne absolue est trop basse, on considère qu'il y a apnée.
    """
    return np.mean(np.abs(emg_signal)) < threshold

def detect_insomnia(eeg_signal, threshold=0.5):
    """
    Détecte l'insomnie à partir du signal EEG.
    Si l'activité cérébrale moyenne est élevée, on suspecte de l'insomnie.
    """
    return np.mean(np.abs(eeg_signal)) > threshold

import pandas as pd
import numpy as np
import re
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Téléchargement des ressources NLTK nécessaires
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('vader_lexicon', quiet=True)
except:
    pass

class SleepDiaryAnalyzer:
    def __init__(self):
        self.sia = SentimentIntensityAnalyzer()
        self.stop_words = set(stopwords.words('french') + stopwords.words('english'))
        self.vectorizer = TfidfVectorizer(max_features=100, stop_words='french')
        self.classifier = None
        
        # Dictionnaires pour l'analyse sémantique
        self.sleep_keywords = {
            'fatigue': ['fatigué', 'épuisé', 'crevé', 'tired', 'exhausted', 'fatigué', 'las'],
            'stress': ['stressé', 'anxieux', 'angoissé', 'stressed', 'worried', 'inquiet'],
            'qualité_positive': ['reposé', 'frais', 'énergique', 'refreshed', 'energetic', 'bien dormi'],
            'qualité_negative': ['mal dormi', 'insomnie', 'réveils', 'cauchemar', 'agité'],
            'durée': ['heures', 'h', 'minutes', 'min', 'temps'],
            'réveils': ['réveillé', 'réveil', 'levé', 'debout', 'wake up', 'woke']
        }
        
        # Patterns regex pour extraction d'entités
        self.time_patterns = {
            'heures': r'(\d+)\s*(?:heures?|h)',
            'minutes': r'(\d+)\s*(?:minutes?|min)',
            'reveils': r'(\d+)\s*(?:fois|réveils?|wake)',
            'heure_coucher': r'(?:couché|dormi|sleep)\s*(?:à|at)\s*(\d{1,2})[h:]?(\d{0,2})',
            'heure_lever': r'(?:levé|réveillé|wake)\s*(?:à|at)\s*(\d{1,2})[h:]?(\d{0,2})'
        }

    def preprocess_text(self, text):
        """Préprocessing du texte"""
        if pd.isna(text):
            return ""
        
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def extract_temporal_entities(self, text):
        """Extraction d'entités temporelles"""
        entities = {}
        text_lower = text.lower()
        
        # Extraction des heures de sommeil
        heures_match = re.search(self.time_patterns['heures'], text_lower)
        if heures_match:
            entities['heures_sommeil'] = int(heures_match.group(1))
        
        # Extraction des minutes
        minutes_match = re.search(self.time_patterns['minutes'], text_lower)
        if minutes_match:
            entities['minutes_sommeil'] = int(minutes_match.group(1))
        
        # Extraction du nombre de réveils
        reveils_match = re.search(self.time_patterns['reveils'], text_lower)
        if reveils_match:
            entities['nb_reveils'] = int(reveils_match.group(1))
        
        return entities

    def analyze_sentiment(self, text):
        """Analyse de sentiment"""
        if not text:
            return {'compound': 0, 'pos': 0, 'neu': 0, 'neg': 0}
        
        scores = self.sia.polarity_scores(text)
        return scores

    def extract_sleep_keywords(self, text):
        """Extraction des mots-clés liés au sommeil"""
        text_lower = text.lower()
        keyword_counts = {}
        
        for category, keywords in self.sleep_keywords.items():
            count = sum(1 for keyword in keywords if keyword in text_lower)
            keyword_counts[f'{category}_keywords'] = count
        
        return keyword_counts

    def classify_sleep_quality(self, sentiment_scores, keywords, temporal_entities):
        """Classification de la qualité du sommeil"""
        score = 0
        
        # Score basé sur le sentiment
        score += sentiment_scores['compound'] * 2
        
        # Score basé sur les mots-clés
        score += keywords.get('qualité_positive_keywords', 0) * 0.5
        score -= keywords.get('qualité_negative_keywords', 0) * 0.5
        score -= keywords.get('fatigue_keywords', 0) * 0.3
        score -= keywords.get('stress_keywords', 0) * 0.4
        
        # Score basé sur les entités temporelles
        if 'heures_sommeil' in temporal_entities:
            heures = temporal_entities['heures_sommeil']
            if 7 <= heures <= 9:
                score += 0.5
            elif heures < 6 or heures > 10:
                score -= 0.5
        
        if 'nb_reveils' in temporal_entities:
            score -= temporal_entities['nb_reveils'] * 0.2
        
        # Classification
        if score > 0.5:
            return "Bonne qualité"
        elif score > -0.5:
            return "Qualité moyenne"
        else:
            return "Mauvaise qualité"

    def detect_sleep_issues(self, text, sentiment_scores, keywords, temporal_entities):
        """Détection de problèmes de sommeil spécifiques"""
        issues = []
        text_lower = text.lower()
        
        # Détection d'insomnie
        insomnia_indicators = ['insomnie', 'pas dormi', 'impossible de dormir', 'réveillé toute la nuit']
        if any(indicator in text_lower for indicator in insomnia_indicators):
            issues.append("Suspicion d'insomnie")
        
        # Détection de stress/anxiété
        if keywords.get('stress_keywords', 0) > 0 or sentiment_scores['neg'] > 0.6:
            issues.append("Stress/Anxiété détecté")
        
        # Détection de sommeil fragmenté
        if temporal_entities.get('nb_reveils', 0) >= 3:
            issues.append("Sommeil fragmenté")
        
        # Détection de durée insuffisante
        if temporal_entities.get('heures_sommeil', 8) < 6:
            issues.append("Durée de sommeil insuffisante")
        
        return issues

    def analyze_single_entry(self, text):
        """Analyse complète d'une entrée de journal"""
        if not text or pd.isna(text):
            return None
        
        # Préprocessing
        processed_text = self.preprocess_text(text)
        
        # Analyses
        sentiment = self.analyze_sentiment(text)
        keywords = self.extract_sleep_keywords(text)
        temporal_entities = self.extract_temporal_entities(text)
        sleep_quality = self.classify_sleep_quality(sentiment, keywords, temporal_entities)
        sleep_issues = self.detect_sleep_issues(text, sentiment, keywords, temporal_entities)
        
        return {
            'texte_original': text,
            'texte_preprocessed': processed_text,
            'sentiment_compound': sentiment['compound'],
            'sentiment_positive': sentiment['pos'],
            'sentiment_negative': sentiment['neg'],
            'sentiment_neutral': sentiment['neu'],
            **keywords,
            **temporal_entities,
            'qualite_sommeil': sleep_quality,
            'problemes_detectes': sleep_issues,
            'score_global': sentiment['compound'] - keywords.get('fatigue_keywords', 0) * 0.1
        }

    def analyze_sleep_diary(self, entries):
        """Analyse d'un journal de sommeil complet"""
        results = []
        
        for entry in entries:
            analysis = self.analyze_single_entry(entry)
            if analysis:
                results.append(analysis)
        
        return pd.DataFrame(results)

    def generate_insights(self, df_analysis):
        """Génération d'insights à partir des analyses"""
        if df_analysis.empty:
            return {}
        
        insights = {
            'total_entries': len(df_analysis),
            'avg_sentiment': df_analysis['sentiment_compound'].mean(),
            'quality_distribution': df_analysis['qualite_sommeil'].value_counts().to_dict(),
            'most_common_issues': [],
            'avg_sleep_hours': None,
            'avg_wake_ups': None
        }
        
        # Problèmes les plus fréquents
        all_issues = []
        for issues_list in df_analysis['problemes_detectes']:
            all_issues.extend(issues_list)
        
        if all_issues:
            from collections import Counter
            insights['most_common_issues'] = dict(Counter(all_issues).most_common(3))
        
        # Moyennes des entités temporelles
        if 'heures_sommeil' in df_analysis.columns:
            insights['avg_sleep_hours'] = df_analysis['heures_sommeil'].mean()
        
        if 'nb_reveils' in df_analysis.columns:
            insights['avg_wake_ups'] = df_analysis['nb_reveils'].mean()
        
        return insights

    def create_visualizations(self, df_analysis):
        """Création de visualisations"""
        if df_analysis.empty:
            return None
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Analyse du Journal de Sommeil', fontsize=16, fontweight='bold')
        
        # 1. Distribution de la qualité du sommeil
        quality_counts = df_analysis['qualite_sommeil'].value_counts()
        axes[0, 0].pie(quality_counts.values, labels=quality_counts.index, autopct='%1.1f%%')
        axes[0, 0].set_title('Distribution de la Qualité du Sommeil')
        
        # 2. Évolution du sentiment dans le temps
        axes[0, 1].plot(df_analysis.index, df_analysis['sentiment_compound'], marker='o')
        axes[0, 1].set_title('Évolution du Sentiment')
        axes[0, 1].set_xlabel('Entrées')
        axes[0, 1].set_ylabel('Score de Sentiment')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Corrélation sentiment vs mots-clés de fatigue
        if 'fatigue_keywords' in df_analysis.columns:
            axes[1, 0].scatter(df_analysis['fatigue_keywords'], df_analysis['sentiment_compound'])
            axes[1, 0].set_xlabel('Mots-clés de Fatigue')
            axes[1, 0].set_ylabel('Score de Sentiment')
            axes[1, 0].set_title('Fatigue vs Sentiment')
        
        # 4. Distribution des heures de sommeil
        if 'heures_sommeil' in df_analysis.columns and not df_analysis['heures_sommeil'].isna().all():
            axes[1, 1].hist(df_analysis['heures_sommeil'].dropna(), bins=10, alpha=0.7)
            axes[1, 1].set_xlabel('Heures de Sommeil')
            axes[1, 1].set_ylabel('Fréquence')
            axes[1, 1].set_title('Distribution des Heures de Sommeil')
        
        plt.tight_layout()
        return fig

# Fonctions utilitaires pour Streamlit
def load_sample_data():
    """Chargement de données d'exemple"""
    sample_entries = [
        "J'ai très mal dormi cette nuit, je me suis réveillé 4 fois et je suis très fatigué ce matin",
        "Excellente nuit de sommeil, j'ai dormi 8 heures d'affilée et je me sens très reposé",
        "Nuit difficile à cause du stress, j'ai mis du temps à m'endormir et j'ai fait des cauchemars",
        "Sommeil correct, environ 7 heures mais quelques réveils nocturnes",
        "Je suis épuisé, seulement 5 heures de sommeil à cause du travail",
        "Très bonne récupération, je me sens énergique et frais ce matin",
        "Insomnie partielle, réveillé à 3h du matin et impossible de me rendormir",
        "Nuit paisible, endormissement rapide et réveil naturel après 8h30 de sommeil"
    ]
    return sample_entries

def run_complete_analysis(entries):
    """Fonction principale pour l'analyse complète"""
    analyzer = SleepDiaryAnalyzer()
    
    # Analyse des entrées
    df_results = analyzer.analyze_sleep_diary(entries)
    
    # Génération d'insights
    insights = analyzer.generate_insights(df_results)
    
    # Création des visualisations
    fig = analyzer.create_visualizations(df_results)
    
    return df_results, insights, fig

# Exemple d'utilisation
if __name__ == "__main__":
    # Test avec des données d'exemple
    sample_data = load_sample_data()
    
    print("=== ANALYSE DU JOURNAL DE SOMMEIL ===\n")
    
    # Analyse
    results_df, insights_dict, visualization = run_complete_analysis(sample_data)
    
    # Affichage des résultats
    print("Résultats de l'analyse:")
    print(f"- Nombre d'entrées analysées: {insights_dict['total_entries']}")
    print(f"- Sentiment moyen: {insights_dict['avg_sentiment']:.3f}")
    print(f"- Distribution de qualité: {insights_dict['quality_distribution']}")
    
    if insights_dict['most_common_issues']:
        print(f"- Problèmes les plus fréquents: {insights_dict['most_common_issues']}")
    
    if insights_dict['avg_sleep_hours']:
        print(f"- Durée moyenne de sommeil: {insights_dict['avg_sleep_hours']:.1f}h")
    
    # Sauvegarde des résultats
    results_df.to_csv('sleep_analysis_results.csv', index=False)
    
    if visualization:
        visualization.savefig('sleep_analysis_visualization.png', dpi=300, bbox_inches='tight')
    
    print("\nAnalyse terminée! Fichiers sauvegardés.")
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime, date
import re
from collections import Counter
import seaborn as sns

# Configuration de la page
st.set_page_config(
    page_title="🌙 Analyseur de Journal de Sommeil",
    page_icon="🌙",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Classe SleepDiaryAnalyzer intégrée
class SleepDiaryAnalyzer:
    def __init__(self):
        # Dictionnaires pour l'analyse de sentiment simple
        self.positive_words = [
            'bien', 'bon', 'excellent', 'parfait', 'reposé', 'calme', 'paisible',
            'récupéré', 'relaxé', 'serein', 'tranquille', 'satisfait', 'content',
            'formidable', 'merveilleux', 'agréable', 'confortable'
        ]
        
        self.negative_words = [
            'mal', 'mauvais', 'terrible', 'affreux', 'fatigué', 'épuisé', 'stressé',
            'anxieux', 'inquiet', 'perturbé', 'difficile', 'problème', 'insomnie',
            'cauchemar', 'réveillé', 'interrompu', 'agité', 'douleur'
        ]
        
        self.sleep_problems = {
            'insomnie': ['insomnie', 'pas dormi', 'difficile à dormir', 'endormir'],
            'reveils_nocturnes': ['réveillé', 'réveil', 'interrompu', '2h', '3h', 'nuit'],
            'cauchemars': ['cauchemar', 'rêve', 'horrible', 'peur'],
            'stress': ['stress', 'anxieux', 'inquiet', 'travail', 'soucis'],
            'douleur': ['mal', 'douleur', 'courbature'],
            'bruit': ['bruit', 'voisin', 'fort', 'dérangé']
        }

    def calculate_sentiment(self, text):
        """Calcul simple du sentiment basé sur les mots positifs/négatifs"""
        text_lower = text.lower()
        positive_count = sum(1 for word in self.positive_words if word in text_lower)
        negative_count = sum(1 for word in self.negative_words if word in text_lower)
        
        total_words = len(text.split())
        if total_words == 0:
            return 0
        
        # Score composite
        compound = (positive_count - negative_count) / max(total_words, 1)
        return max(-1, min(1, compound * 10))  # Normaliser entre -1 et 1

    def extract_sleep_hours(self, text):
        """Extraction des heures de sommeil mentionnées"""
        patterns = [
            r'(\d+)h\d*\s*de\s*sommeil',
            r'dormi\s*(\d+)h',
            r'(\d+)\s*heures\s*de\s*sommeil',
            r'couché\s*à\s*(\d+)h.*levé\s*à\s*(\d+)h'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                if len(match.groups()) == 2:  # Pattern couché/levé
                    sleep_time = int(match.group(1))
                    wake_time = int(match.group(2))
                    if wake_time > sleep_time:
                        return wake_time - sleep_time
                    else:
                        return (24 - sleep_time) + wake_time
                else:
                    return int(match.group(1))
        return None

    def extract_wake_ups(self, text):
        """Extraction du nombre de réveils nocturnes"""
        patterns = [
            r'réveillé\s*(\d+)\s*fois',
            r'(\d+)\s*réveils?',
            r'interrompu\s*(\d+)\s*fois'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text.lower())
            if match:
                return int(match.group(1))
        
        # Détection de réveils mentionnés sans nombre
        if any(word in text.lower() for word in ['réveillé', 'réveil', 'interrompu']):
            return 1
        return 0

    def detect_problems(self, text):
        """Détection des problèmes de sommeil"""
        detected = []
        text_lower = text.lower()
        
        for problem, keywords in self.sleep_problems.items():
            if any(keyword in text_lower for keyword in keywords):
                detected.append(problem)
        
        return detected

    def classify_sleep_quality(self, sentiment_score, wake_ups, sleep_hours):
        """Classification de la qualité du sommeil"""
        score = 0
        
        # Sentiment
        if sentiment_score > 0.3:
            score += 2
        elif sentiment_score > 0:
            score += 1
        elif sentiment_score < -0.3:
            score -= 2
        else:
            score -= 1
        
        # Réveils
        if wake_ups == 0:
            score += 2
        elif wake_ups <= 1:
            score += 1
        elif wake_ups <= 3:
            score -= 1
        else:
            score -= 2
        
        # Heures de sommeil
        if sleep_hours and 7 <= sleep_hours <= 9:
            score += 2
        elif sleep_hours and 6 <= sleep_hours <= 10:
            score += 1
        elif sleep_hours and sleep_hours < 6:
            score -= 2
        
        if score >= 3:
            return "Bonne qualité"
        elif score >= 0:
            return "Qualité moyenne"
        else:
            return "Mauvaise qualité"

    def analyze_single_entry(self, text):
        """Analyse complète d'une entrée"""
        sentiment = self.calculate_sentiment(text)
        sleep_hours = self.extract_sleep_hours(text)
        wake_ups = self.extract_wake_ups(text)
        problems = self.detect_problems(text)
        quality = self.classify_sleep_quality(sentiment, wake_ups, sleep_hours)
        
        # Score global (combinaison des facteurs)
        global_score = sentiment
        if wake_ups > 2:
            global_score -= 0.5
        if sleep_hours and sleep_hours < 6:
            global_score -= 0.3
        
        return {
            'sentiment_compound': sentiment,
            'sentiment_positive': max(0, sentiment),
            'sentiment_negative': abs(min(0, sentiment)),
            'sentiment_neutral': 1 - abs(sentiment),
            'heures_sommeil': sleep_hours,
            'nb_reveils': wake_ups,
            'problemes_detectes': problems,
            'qualite_sommeil': quality,
            'score_global': global_score
        }

    def analyze_multiple_entries(self, descriptions):
        """Analyse de multiples entrées"""
        results = []
        for desc in descriptions:
            result = self.analyze_single_entry(desc)
            result['description'] = desc
            results.append(result)
        
        return pd.DataFrame(results)

def get_sample_data():
    """Données d'exemple pour tester l'application"""
    return [
        "J'ai très bien dormi cette nuit, je me suis couché à 22h30 et levé à 7h. Je me sens parfaitement reposé ce matin.",
        "Nuit difficile, je me suis réveillé 3 fois vers 2h du matin à cause du bruit des voisins. Je suis fatigué.",
        "Sommeil correct, environ 7h de sommeil mais j'ai fait des cauchemars. Je me sens moyennement reposé.",
        "Excellente nuit ! Dormi d'une traite pendant 8h, aucun réveil. Je me sens en forme ce matin.",
        "Très mal dormi, insomnie à cause du stress du travail. Seulement 4h de sommeil, je suis épuisé.",
        "Nuit paisible et réparatrice, je me sens calme et serein au réveil. Parfait pour commencer la journée.",
        "Réveillé 2 fois dans la nuit, mais j'ai réussi à me rendormir facilement. Pas trop mal dans l'ensemble."
    ]

def run_complete_analysis(descriptions):
    """Analyse complète avec insights"""
    analyzer = SleepDiaryAnalyzer()
    df = analyzer.analyze_multiple_entries(descriptions)
    
    # Calcul des insights
    insights = {
        'total_entries': len(df),
        'avg_sentiment': df['sentiment_compound'].mean(),
        'avg_sleep_hours': df[df['heures_sommeil'].notna()]['heures_sommeil'].mean() if df['heures_sommeil'].notna().any() else None,
        'avg_wake_ups': df['nb_reveils'].mean(),
        'quality_distribution': df['qualite_sommeil'].value_counts().to_dict(),
        'most_common_issues': {}
    }
    
    # Problèmes les plus fréquents
    all_problems = [problem for problems in df['problemes_detectes'] for problem in problems]
    if all_problems:
        insights['most_common_issues'] = dict(Counter(all_problems).most_common(5))
    
    return df, insights

# CSS personnalisé pour améliorer l'apparence
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
        margin: 0.5rem 0;
    }
    .insight-box {
        background: #e8f4f8;
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #bee5eb;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def init_session_state():
    """Initialisation des variables de session"""
    if 'sleep_entries' not in st.session_state:
        st.session_state.sleep_entries = []
    if 'analysis_results' not in st.session_state:
        st.session_state.analysis_results = None
    if 'analyzer' not in st.session_state:
        st.session_state.analyzer = SleepDiaryAnalyzer()

def show_data_input():
    """Section de saisie des données"""
    st.markdown('<div class="section-header"><h3>📝 Saisie de votre journal de sommeil</h3></div>', unsafe_allow_html=True)
    
    # Tabs pour différents modes de saisie
    tab1, tab2, tab3 = st.tabs(["✍️ Saisie manuelle", "📄 Import fichier", "🎯 Données d'exemple"])
    
    with tab1:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Décrivez votre nuit")
            
            # Date de la nuit
            sleep_date = st.date_input("Date de la nuit", value=date.today())
            
            # Zone de texte pour la description
            sleep_description = st.text_area(
                "Comment s'est passée votre nuit ?",
                placeholder="Exemple: J'ai mal dormi cette nuit, je me suis réveillé 3 fois vers 2h du matin. Je me sens fatigué ce matin...",
                height=150
            )
            
            # Boutons d'action
            col_btn1, col_btn2 = st.columns(2)
            with col_btn1:
                if st.button("➕ Ajouter cette entrée", type="primary"):
                    if sleep_description.strip():
                        entry = {
                            'date': sleep_date,
                            'description': sleep_description,
                            'timestamp': datetime.now()
                        }
                        st.session_state.sleep_entries.append(entry)
                        st.success("✅ Entrée ajoutée avec succès!")
                        st.rerun()
            
            with col_btn2:
                if st.button("🔍 Analyser cette entrée"):
                    if sleep_description.strip():
                        quick_analysis = st.session_state.analyzer.analyze_single_entry(sleep_description)
                        st.session_state.temp_quick_analysis = quick_analysis
                        st.rerun()
        
        with col2:
            st.subheader("💡 Conseils de saisie")
            st.info("""
            **Pour une meilleure analyse, mentionnez :**
            - Votre ressenti au réveil
            - Nombre de réveils nocturnes  
            - Durée approximative de sommeil
            - Facteurs perturbateurs
            - État émotionnel
            
            **Exemples :**
            - "Je me suis couché à 23h et levé à 7h"
            - "Réveillé 2 fois dans la nuit"
            - "Je me sens fatigué/reposé"
            - "Stress à cause du travail"
            """)
        
        # Affichage de l'analyse rapide
        if hasattr(st.session_state, 'temp_quick_analysis'):
            show_quick_analysis(st.session_state.temp_quick_analysis)
            del st.session_state.temp_quick_analysis
    
    with tab2:
        st.subheader("📄 Importer un fichier")
        uploaded_file = st.file_uploader(
            "Choisir un fichier CSV",
            type=['csv', 'txt'],
            help="Le fichier doit contenir une colonne 'description' avec vos entrées de sommeil"
        )
        
        if uploaded_file:
            try:
                df = pd.read_csv(uploaded_file)
                st.dataframe(df.head())
                
                if 'description' in df.columns:
                    if st.button("📥 Importer ces données"):
                        for _, row in df.iterrows():
                            entry = {
                                'date': row.get('date', date.today()),
                                'description': row['description'],
                                'timestamp': datetime.now()
                            }
                            st.session_state.sleep_entries.append(entry)
                        st.success(f"✅ {len(df)} entrées importées!")
                        st.rerun()
                else:
                    st.error("❌ Le fichier doit contenir une colonne 'description'")
            except Exception as e:
                st.error(f"❌ Erreur lors de la lecture du fichier: {e}")
    
    with tab3:
        st.subheader("🎯 Données d'exemple")
        st.info("Utilisez ces données pour tester l'analyseur")
        
        if st.button("📥 Charger les données d'exemple"):
            sample_data = get_sample_data()
            for i, desc in enumerate(sample_data):
                entry = {
                    'date': date.today(),
                    'description': desc,
                    'timestamp': datetime.now()
                }
                st.session_state.sleep_entries.append(entry)
            st.success(f"✅ {len(sample_data)} entrées d'exemple ajoutées!")
            st.rerun()
    
    # Affichage des entrées actuelles
    if st.session_state.sleep_entries:
        st.subheader("📋 Vos entrées actuelles")
        
        for i, entry in enumerate(st.session_state.sleep_entries):
            with st.expander(f"📅 {entry['date']} - Entrée #{i+1}"):
                st.write(f"**Description:** {entry['description']}")
                st.write(f"**Ajoutée le:** {entry['timestamp'].strftime('%d/%m/%Y %H:%M')}")
                
                if st.button(f"🗑️ Supprimer", key=f"del_{i}"):
                    st.session_state.sleep_entries.pop(i)
                    st.rerun()

def show_quick_analysis(analysis):
    """Affichage rapide d'une analyse"""
    st.subheader("🔍 Analyse rapide")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        sentiment_color = "green" if analysis['sentiment_compound'] > 0 else "red"
        st.markdown(f"""
        <div class="metric-card">
            <h4>😊 Sentiment</h4>
            <h2 style="color: {sentiment_color}">{analysis['sentiment_compound']:.2f}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        quality_color = {"Bonne qualité": "green", "Qualité moyenne": "orange", "Mauvaise qualité": "red"}
        st.markdown(f"""
        <div class="metric-card">
            <h4>🛌 Qualité</h4>
            <h3 style="color: {quality_color.get(analysis['qualite_sommeil'], 'gray')}">{analysis['qualite_sommeil']}</h3>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        score_color = "green" if analysis['score_global'] > 0 else "red"
        st.markdown(f"""
        <div class="metric-card">
            <h4>📊 Score Global</h4>
            <h2 style="color: {score_color}">{analysis['score_global']:.2f}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    if analysis['problemes_detectes']:
        st.warning(f"⚠️ **Problèmes détectés:** {', '.join(analysis['problemes_detectes'])}")

def show_analysis_results():
    """Section des résultats d'analyse"""
    st.header("📊 Analyse et résultats")
    
    if not st.session_state.sleep_entries:
        st.warning("⚠️ Aucune entrée de sommeil trouvée. Ajoutez des données dans la section 'Saisie des données'.")
        return
    
    # Bouton pour lancer l'analyse complète
    if st.button("🚀 Lancer l'analyse complète", type="primary"):
        with st.spinner("🔄 Analyse en cours..."):
            descriptions = [entry['description'] for entry in st.session_state.sleep_entries]
            results_df, insights = run_complete_analysis(descriptions)
            st.session_state.analysis_results = {
                'dataframe': results_df,
                'insights': insights
            }
        st.success("✅ Analyse terminée!")
        st.rerun()
    
    # Affichage des résultats si disponibles
    if st.session_state.analysis_results:
        results = st.session_state.analysis_results
        df = results['dataframe']
        insights = results['insights']
        
        # Métriques principales
        st.subheader("📈 Métriques principales")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("📝 Entrées analysées", insights['total_entries'])
        
        with col2:
            sentiment_delta = insights['avg_sentiment']
            st.metric("😊 Sentiment moyen", f"{sentiment_delta:.3f}", delta=f"{sentiment_delta:.3f}")
        
        with col3:
            if insights.get('avg_sleep_hours'):
                st.metric("⏰ Heures moy.", f"{insights['avg_sleep_hours']:.1f}h")
            else:
                st.metric("⏰ Heures moy.", "N/A")
        
        with col4:
            if insights.get('avg_wake_ups'):
                st.metric("🔄 Réveils moy.", f"{insights['avg_wake_ups']:.1f}")
            else:
                st.metric("🔄 Réveils moy.", "N/A")
        
        # Graphiques
        st.subheader("📊 Visualisations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Distribution de la qualité du sommeil
            if insights['quality_distribution']:
                fig1, ax1 = plt.subplots(figsize=(8, 6))
                quality_dist = pd.Series(insights['quality_distribution'])
                colors = ['#ff9999', '#66b3ff', '#99ff99']
                ax1.pie(quality_dist.values, labels=quality_dist.index, autopct='%1.1f%%', colors=colors)
                ax1.set_title("Distribution de la Qualité du Sommeil")
                st.pyplot(fig1)
                plt.close()
        
        with col2:
            # Évolution du sentiment
            fig2, ax2 = plt.subplots(figsize=(8, 6))
            ax2.plot(range(len(df)), df['sentiment_compound'], marker='o', color='#667eea')
            ax2.axhline(y=0, color='red', linestyle='--', alpha=0.7)
            ax2.set_title("Évolution du Sentiment")
            ax2.set_xlabel("Entrées")
            ax2.set_ylabel("Score de Sentiment")
            ax2.grid(True, alpha=0.3)
            st.pyplot(fig2)
            plt.close()
        
        # Problèmes les plus fréquents
        if insights['most_common_issues']:
            st.subheader("⚠️ Problèmes les plus fréquents")
            issues_df = pd.DataFrame(list(insights['most_common_issues'].items()), 
                                   columns=['Problème', 'Fréquence'])
            fig3, ax3 = plt.subplots(figsize=(10, 6))
            bars = ax3.bar(issues_df['Problème'], issues_df['Fréquence'], color='#ff9999')
            ax3.set_title("Fréquence des Problèmes Détectés")
            ax3.set_xlabel("Problème")
            ax3.set_ylabel("Fréquence")
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            st.pyplot(fig3)
            plt.close()
        
        # Tableau détaillé
        st.subheader("📋 Résultats détaillés")
        
        # Filtrages
        col1, col2 = st.columns(2)
        with col1:
            quality_filter = st.multiselect(
                "Filtrer par qualité",
                options=df['qualite_sommeil'].unique(),
                default=df['qualite_sommeil'].unique()
            )
        
        with col2:
            sentiment_min = st.slider(
                "Sentiment minimum",
                min_value=float(df['sentiment_compound'].min()),
                max_value=float(df['sentiment_compound'].max()),
                value=float(df['sentiment_compound'].min())
            )
        
        # Application des filtres
        filtered_df = df[
            (df['qualite_sommeil'].isin(quality_filter)) &
            (df['sentiment_compound'] >= sentiment_min)
        ]
        
        st.dataframe(filtered_df, use_container_width=True)
        
        # Bouton de téléchargement
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Télécharger les résultats (CSV)",
            data=csv,
            file_name=f"analyse_sommeil_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv"
        )

def show_trends():
    """Section des tendances et historique"""
    st.header("📈 Historique et tendances")
    
    if not st.session_state.analysis_results:
        st.warning("⚠️ Lancez d'abord une analyse complète dans la section 'Analyse et résultats'.")
        return
    
    df = st.session_state.analysis_results['dataframe']
    
    # Analyse temporelle
    if st.session_state.sleep_entries:
        dates = [entry['date'] for entry in st.session_state.sleep_entries[-len(df):]]
        df_with_dates = df.copy()
        df_with_dates['date'] = dates
        
        # Graphique d'évolution temporelle
        fig1, ax1 = plt.subplots(figsize=(12, 6))
        ax1.plot(df_with_dates['date'], df_with_dates['sentiment_compound'], marker='o', color='#667eea')
        ax1.set_title("Évolution du sentiment dans le temps")
        ax1.set_xlabel("Date")
        ax1.set_ylabel("Score de Sentiment")
        ax1.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        plt.tight_layout()
        st.pyplot(fig1)
        plt.close()
        
        # Analyse par jour de la semaine
        df_with_dates['day_of_week'] = pd.to_datetime(df_with_dates['date']).dt.day_name()
        daily_avg = df_with_dates.groupby('day_of_week')['sentiment_compound'].mean().reset_index()
        
        fig2, ax2 = plt.subplots(figsize=(10, 6))
        bars = ax2.bar(daily_avg['day_of_week'], daily_avg['sentiment_compound'], color='#764ba2')
        ax2.set_title("Sentiment moyen par jour de la semaine")
        ax2.set_xlabel("Jour de la semaine")
        ax2.set_ylabel("Score de Sentiment")
        plt.xticks(rotation=45)
        plt.tight_layout()
        st.pyplot(fig2)
        plt.close()

def show_settings():
    """Section des paramètres"""
    st.header("⚙️ Paramètres")
    
    st.subheader("🗑️ Gestion des données")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🗑️ Effacer toutes les entrées", type="secondary"):
            st.session_state.sleep_entries = []
            st.success("✅ Toutes les entrées ont été supprimées")
            st.rerun()
    
    with col2:
        if st.button("🔄 Réinitialiser l'analyse"):
            st.session_state.analysis_results = None
            st.success("✅ Analyse réinitialisée")
            st.rerun()
    
    st.subheader("📊 Statistiques de session")
    st.write(f"- Nombre d'entrées: {len(st.session_state.sleep_entries)}")
    st.write(f"- Analyse disponible: {'Oui' if st.session_state.analysis_results else 'Non'}")
    
    st.subheader("ℹ️ À propos")
    st.info("""
    **Analyseur de Journal de Sommeil v1.0**
    
    Cet outil utilise des techniques de traitement du langage naturel (NLP) pour analyser vos descriptions de sommeil :
    - Analyse de sentiment personnalisée
    - Extraction d'entités temporelles
    - Classification automatique de la qualité
    - Détection de problèmes de sommeil
    
    Développé avec Streamlit et Python.
    """)

def main():
    """Fonction principale de l'application"""
    init_session_state()
    
    # En-tête principal
    st.markdown("""
    <div class="main-header">
        <h1>🌙 Analyseur de Journal de Sommeil</h1>
        <p>Analyse intelligente de vos nuits avec traitement du langage naturel</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar pour la navigation
    st.sidebar.title("🔧 Options")
    page = st.sidebar.selectbox(
        "Choisir une section",
        ["📝 Saisie des données", "📊 Analyse et résultats", "📈 Historique et tendances", "⚙️ Paramètres"]
    )
    
    if page == "📝 Saisie des données":
        show_data_input()
    elif page == "📊 Analyse et résultats":
        show_analysis_results()
    elif page == "📈 Historique et tendances":
        show_trends()
    elif page == "⚙️ Paramètres":
        show_settings()

if __name__ == "__main__":
    main()
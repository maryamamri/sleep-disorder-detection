# app/model/predictor.py
def predict_signals(df, sampling_rate):
    # Exemple : renvoyer la colonne "EEG Fpz-Cz" avec du bruit
    import numpy as np
    if 'EEG Fpz-Cz' in df.columns:
        eeg_pred = df['EEG Fpz-Cz'] + np.random.normal(0, 0.01, len(df))
    else:
        eeg_pred = np.zeros(len(df))

    emg_pred = np.zeros(len(df))  # Fake data
    return eeg_pred, emg_pred

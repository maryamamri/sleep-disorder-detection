import numpy as np

def detect_sleep_disorders(eeg_signal, emg_signal, threshold_eeg=0.5, threshold_emg=0.2):
    """
    Détecte l'apnée et l'insomnie à partir des signaux EEG et EMG.

    Arguments :
    - eeg_signal : signal EEG prédit
    - emg_signal : signal EMG prédit
    - threshold_eeg : seuil pour détecter l'insomnie (activité cérébrale élevée)
    - threshold_emg : seuil pour détecter l'apnée (faible activité musculaire)

    Retourne :
    - dict avec les détections : {"apnea": bool, "insomnia": bool}
    """
    insomnia_detected = np.mean(np.abs(eeg_signal)) > threshold_eeg
    apnea_detected = np.mean(np.abs(emg_signal)) < threshold_emg

    return {
        "apnea": apnea_detected,
        "insomnia": insomnia_detected
    }

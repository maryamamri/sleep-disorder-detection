import mne
import pandas as pd

def convert_edf_to_csv(edf_path):
    raw = mne.io.read_raw_edf(edf_path, preload=True)
    data, times = raw.get_data(return_times=True)

    df = pd.DataFrame(data.T, columns=raw.ch_names)
    df['time'] = times

    return df, int(raw.info['sfreq'])  # dataframe + sampling rate

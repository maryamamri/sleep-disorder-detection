import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import mne
import os
import pickle
import joblib
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
from preprocessing.edf_to_csv import convert_edf_to_csv
from model.predictor import predict_signals

# Configuration de la page
st.set_page_config(
    page_title="Analyse du Sommeil - IA", 
    layout="wide",
    initial_sidebar_state="expanded",
    page_icon="🧠"
)

# CSS personnalisé pour un design moderne
st.markdown("""
<style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Variables CSS */
    :root {
        --primary-color: #667eea;
        --secondary-color: #764ba2;
        --accent-color: #f093fb;
        --success-color: #4ecdc4;
        --warning-color: #ffe66d;
        --error-color: #ff6b6b;
        --dark-bg: #1a1a2e;
        --card-bg: rgba(255, 255, 255, 0.1);
        --text-primary: #2c3e50;
        --text-secondary: #7f8c8d;
        --gradient-1: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        --gradient-2: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        --gradient-3: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        --shadow: 0 10px 30px rgba(0,0,0,0.1);
        --border-radius: 15px;
    }
    
    /* Corps principal */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1200px;
    }
    
    /* Header principal avec gradient */
    .main-header {
        background: var(--gradient-1);
        padding: 2rem;
        border-radius: var(--border-radius);
        text-align: center;
        margin-bottom: 2rem;
        box-shadow: var(--shadow);
        position: relative;
        overflow: hidden;
    }
    
    .main-header::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="white" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
        opacity: 0.3;
    }
    
    .main-header h1 {
        color: white !important;
        font-family: 'Inter', sans-serif;
        font-weight: 700;
        font-size: 2.5rem;
        margin: 0;
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        position: relative;
        z-index: 1;
    }
    
    .main-header p {
        color: rgba(255,255,255,0.9) !important;
        font-size: 1.2rem;
        margin-top: 0.5rem;
        position: relative;
        z-index: 1;
    }
    
    /* Cards avec effet glassmorphism */
    .custom-card {
        background: rgba(255, 255, 255, 0.25);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: var(--border-radius);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }
    
    .custom-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    }
    
    /* Métriques stylisées */
    .metric-container {
        display: flex;
        justify-content: space-around;
        margin: 2rem 0;
        flex-wrap: wrap;
        gap: 1rem;
    }
    
    .metric-card {
        background: var(--gradient-3);
        color: white;
        padding: 1.5rem;
        border-radius: var(--border-radius);
        text-align: center;
        min-width: 150px;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    
    .metric-card::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
        transform: rotate(45deg);
        transition: all 0.6s;
        opacity: 0;
    }
    
    .metric-card:hover::before {
        opacity: 1;
        animation: shine 0.6s ease-in-out;
    }
    
    @keyframes shine {
        0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
        100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
    }
    
    .metric-card:hover {
        transform: scale(1.05);
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        margin: 0;
    }
    
    .metric-label {
        font-size: 0.9rem;
        opacity: 0.9;
        margin-top: 0.5rem;
    }
    
    /* Boutons avec animations */
    .stButton > button {
        background: var(--gradient-2) !important;
        color: white !important;
        border: none !important;
        border-radius: var(--border-radius) !important;
        padding: 0.75rem 2rem !important;
        font-weight: 600 !important;
        font-family: 'Inter', sans-serif !important;
        transition: all 0.3s ease !important;
        box-shadow: var(--shadow) !important;
        position: relative !important;
        overflow: hidden !important;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 15px 35px rgba(0,0,0,0.2) !important;
    }
    
    .stButton > button:active {
        transform: translateY(0) !important;
    }
    
    /* Sidebar moderne */
    .css-1d391kg {
        background: linear-gradient(180deg, #667eea 0%, #764ba2 100%) !important;
    }
    
    .css-1d391kg .css-1v3fvcr {
        color: white !important;
    }
    
    /* Upload zone stylisée */
    .uploadedFile {
        background: var(--card-bg) !important;
        border: 2px dashed var(--primary-color) !important;
        border-radius: var(--border-radius) !important;
        padding: 2rem !important;
        text-align: center !important;
        transition: all 0.3s ease !important;
    }
    
    .uploadedFile:hover {
        border-color: var(--accent-color) !important;
        background: rgba(102, 126, 234, 0.1) !important;
    }
    
    /* Status indicators */
    .status-success {
        background: linear-gradient(135deg, #4ecdc4, #44a08d);
        color: white;
        padding: 1rem;
        border-radius: var(--border-radius);
        margin: 1rem 0;
        box-shadow: var(--shadow);
        animation: slideInUp 0.5s ease;
    }
    
    .status-warning {
        background: linear-gradient(135deg, #ffe66d, #ff6b35);
        color: white;
        padding: 1rem;
        border-radius: var(--border-radius);
        margin: 1rem 0;
        box-shadow: var(--shadow);
        animation: slideInUp 0.5s ease;
    }
    
    .status-error {
        background: linear-gradient(135deg, #ff6b6b, #ee5a52);
        color: white;
        padding: 1rem;
        border-radius: var(--border-radius);
        margin: 1rem 0;
        box-shadow: var(--shadow);
        animation: slideInUp 0.5s ease;
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* Tables stylisées */
    .dataframe {
        border-radius: var(--border-radius) !important;
        overflow: hidden !important;
        box-shadow: var(--shadow) !important;
    }
    
    /* Progress bars */
    .stProgress > div > div > div {
        background: var(--gradient-1) !important;
    }
    
    /* Expanders */
    .streamlit-expanderHeader {
        background: var(--card-bg) !important;
        border-radius: var(--border-radius) !important;
        border: 1px solid rgba(255, 255, 255, 0.18) !important;
    }
    
    /* Section headers */
    .section-header {
        background: var(--gradient-2);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        margin: 2rem 0 1rem 0;
        box-shadow: var(--shadow);
        position: relative;
        overflow: hidden;
    }
    
    .section-header::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 100px;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1));
        animation: slideRight 2s infinite;
    }
    
    @keyframes slideRight {
        0% { transform: translateX(-100px); }
        100% { transform: translateX(100px); }
    }
    
    /* Animations pour les éléments */
    .animate-fade-in {
        animation: fadeIn 0.8s ease-in-out;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Responsive design */
    @media (max-width: 768px) {
        .main-header h1 {
            font-size: 2rem;
        }
        
        .metric-container {
            flex-direction: column;
            align-items: center;
        }
        
        .custom-card {
            margin: 0.5rem 0;
        }
    }
    
    /* Dark mode support */
    @media (prefers-color-scheme: dark) {
        .custom-card {
            background: rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
    }
    
    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.1);
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: var(--gradient-1);
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: var(--gradient-2);
    }
</style>
""", unsafe_allow_html=True)

# Header principal avec design moderne
st.markdown("""
<div class="main-header animate-fade-in">
    <h1>🧠 Analyse Avancée du Sommeil</h1>
    <p>Intelligence Artificielle & Traitement de Signaux Biomédicaux</p>
</div>
""", unsafe_allow_html=True)

# Configuration matplotlib
try:
    plt.style.use('seaborn-v0_8')
except OSError:
    try:
        plt.style.use('seaborn')
    except OSError:
        plt.style.use('default')

try:
    sns.set_palette("husl")
except:
    pass

# Sidebar avec style personnalisé
st.sidebar.markdown("""
<div style="text-align: center; padding: 1rem; color: white;">
    <h2>⚙️ Centre de Contrôle</h2>
    <p style="opacity: 0.8;">Configurez vos paramètres d'analyse</p>
</div>
""", unsafe_allow_html=True)

# Upload du fichier avec design personnalisé
st.markdown('<div class="section-header"><h3>📁 Import de Données</h3></div>', unsafe_allow_html=True)

uploaded_file = st.file_uploader(
    "Glissez-déposez votre fichier .edf ici", 
    type=["edf"],
    help="Formats supportés: EDF (European Data Format)"
)

if uploaded_file is not None:
    # Message de succès avec animation
    st.markdown('''
    <div class="status-success">
        <strong>✅ Fichier chargé avec succès!</strong><br>
        Prêt pour l'analyse des signaux biomédicaux
    </div>
    ''', unsafe_allow_html=True)
    
    # Création du dossier temporaire
    os.makedirs("temp", exist_ok=True)
    
    # Sauvegarde temporaire
    edf_path = os.path.join("temp", uploaded_file.name)
    with open(edf_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    # Conversion avec indicateur de progression
    with st.spinner("🔄 Conversion en cours..."):
        progress_bar = st.progress(0)
        for i in range(100):
            progress_bar.progress(i + 1)
        
        try:
            csv_data, sampling_rate = convert_edf_to_csv(edf_path)
            
            # Métriques avec design moderne
            st.markdown('<div class="section-header"><h3>📊 Informations du Dataset</h3></div>', unsafe_allow_html=True)
            
            st.markdown(f"""
            <div class="metric-container">
                <div class="metric-card">
                    <div class="metric-value">{len(csv_data):,}</div>
                    <div class="metric-label">Échantillons</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{sampling_rate}</div>
                    <div class="metric-label">Hz</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{len(csv_data.columns)}</div>
                    <div class="metric-label">Canaux</div>
                </div>
                <div class="metric-card">
                    <div class="metric-value">{len(csv_data)/sampling_rate:.1f}</div>
                    <div class="metric-label">Secondes</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
        except Exception as e:
            st.markdown(f'''
            <div class="status-error">
                <strong>❌ Erreur de conversion:</strong><br>
                {str(e)}
            </div>
            ''', unsafe_allow_html=True)
            st.stop()
    
    # Aperçu des données dans une card
    st.markdown('<div class="section-header"><h3>📋 Aperçu des Données</h3></div>', unsafe_allow_html=True)
    
    with st.container():
        st.markdown('<div class="custom-card">', unsafe_allow_html=True)
        st.dataframe(
            csv_data.head(10), 
            use_container_width=True,
            height=300
        )
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Paramètres dans la sidebar
    st.sidebar.markdown("### 🔧 Prétraitement")
    
    remove_missing = st.sidebar.checkbox("🧹 Nettoyer les données", value=True)
    normalize_signals = st.sidebar.checkbox("📏 Normaliser", value=True)
    
    if normalize_signals:
        normalization_method = st.sidebar.selectbox(
            "Méthode de normalisation",
            ["StandardScaler (Z-score)", "MinMaxScaler (0-1)", "RobustScaler"],
            help="Choisissez la méthode de normalisation appropriée"
        )
    
    # Application du prétraitement
    processed_data = csv_data.copy()
    preprocessing_info = []
    
    with st.spinner("🔄 Prétraitement en cours..."):
        if remove_missing:
            missing_before = processed_data.isnull().sum().sum()
            processed_data = processed_data.dropna()
            missing_after = len(csv_data) - len(processed_data)
            preprocessing_info.append(f"✅ {missing_after} valeurs manquantes supprimées")
            
            if processed_data.isnull().sum().sum() > 0:
                processed_data = processed_data.interpolate(method='linear')
                preprocessing_info.append("✅ Interpolation appliquée")
        
        if normalize_signals:
            if normalization_method == "StandardScaler (Z-score)":
                scaler = StandardScaler()
                processed_data[processed_data.columns] = scaler.fit_transform(processed_data)
                preprocessing_info.append("✅ Z-score appliqué")
            elif normalization_method == "MinMaxScaler (0-1)":
                scaler = MinMaxScaler()
                processed_data[processed_data.columns] = scaler.fit_transform(processed_data)
                preprocessing_info.append("✅ Min-Max appliqué")
            elif normalization_method == "RobustScaler":
                scaler = RobustScaler()
                processed_data[processed_data.columns] = scaler.fit_transform(processed_data)
                preprocessing_info.append("✅ Normalisation robuste appliquée")
    
    # Affichage des infos de prétraitement
    if preprocessing_info:
        st.sidebar.markdown(f'''
        <div class="status-success" style="font-size: 0.8rem;">
            {chr(10).join(preprocessing_info)}
        </div>
        ''', unsafe_allow_html=True)
    
    csv_data = processed_data
    
    # Paramètres de visualisation
    st.sidebar.markdown("### 📊 Visualisation")
    
    available_channels = csv_data.columns.tolist()
    selected_channels = st.sidebar.multiselect(
        "Canaux à analyser",
        available_channels,
        default=available_channels[:min(4, len(available_channels))]
    )
    
    max_duration = min(300, len(csv_data) // sampling_rate)
    duration_seconds = st.sidebar.slider(
        "Durée (secondes)",
        min_value=10,
        max_value=max_duration,
        value=min(30, max_duration),
        step=10
    )
    
    max_start_time = max(0, len(csv_data) // sampling_rate - duration_seconds)
    start_time = st.sidebar.slider(
        "Début (secondes)",
        min_value=0,
        max_value=max_start_time,
        value=0,
        step=5
    )
    
    # Visualisation des signaux
    if selected_channels:
        st.markdown('<div class="section-header"><h3>📈 Signaux Biomédicaux</h3></div>', unsafe_allow_html=True)
        
        start_idx = int(start_time * sampling_rate)
        end_idx = int((start_time + duration_seconds) * sampling_rate)
        end_idx = min(end_idx, len(csv_data))
        
        time_vector = np.arange(start_idx, end_idx) / sampling_rate
        
        # Création du graphique
        fig, axes = plt.subplots(
            len(selected_channels), 1, 
            figsize=(12, 3 * len(selected_channels)),
            sharex=True,
            facecolor='white'
        )
        
        if len(selected_channels) == 1:
            axes = [axes]
        
        colors = plt.cm.viridis(np.linspace(0, 1, len(selected_channels)))
        
        for i, channel in enumerate(selected_channels):
            if channel in csv_data.columns:
                signal_data = csv_data[channel].iloc[start_idx:end_idx]
                
                axes[i].plot(
                    time_vector, 
                    signal_data, 
                    color=colors[i],
                    linewidth=1.2,
                    alpha=0.8
                )
                axes[i].set_ylabel(f"{channel}\n(µV)", fontsize=10)
                axes[i].grid(True, alpha=0.3)
                axes[i].set_title(f"Canal {channel}", fontsize=12, pad=15)
                
                mean_val = np.mean(signal_data)
                std_val = np.std(signal_data)
                axes[i].axhline(y=mean_val, color='red', linestyle='--', alpha=0.7, linewidth=1)
                axes[i].fill_between(
                    time_vector, 
                    mean_val - std_val, 
                    mean_val + std_val, 
                    alpha=0.2, 
                    color=colors[i]
                )
        
        axes[-1].set_xlabel("Temps (s)", fontsize=12)
        plt.suptitle("Analyse des Signaux EEG/EMG", fontsize=16, y=0.98)
        plt.tight_layout()
        
        st.pyplot(fig)
        plt.close()
        
        # Statistiques avec design moderne
        st.markdown('<div class="section-header"><h3>📊 Statistiques Détaillées</h3></div>', unsafe_allow_html=True)
        
        stats_data = []
        for channel in selected_channels:
            if channel in csv_data.columns:
                signal_segment = csv_data[channel].iloc[start_idx:end_idx]
                stats_data.append({
                    'Canal': channel,
                    'Moyenne (µV)': f"{np.mean(signal_segment):.3f}",
                    'Écart-type (µV)': f"{np.std(signal_segment):.3f}",
                    'Min (µV)': f"{np.min(signal_segment):.3f}",
                    'Max (µV)': f"{np.max(signal_segment):.3f}",
                    'RMS (µV)': f"{np.sqrt(np.mean(signal_segment**2)):.3f}"
                })
        
        stats_df = pd.DataFrame(stats_data)
        
        st.markdown('<div class="custom-card">', unsafe_allow_html=True)
        st.dataframe(stats_df, use_container_width=True)
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Analyse spectrale
        st.markdown('<div class="section-header"><h3>🌊 Analyse Spectrale Avancée</h3></div>', unsafe_allow_html=True)
        
        spectral_channel = st.selectbox(
            "Canal pour analyse spectrale",
            selected_channels,
            help="Sélectionnez le canal à analyser dans le domaine fréquentiel"
        )
        
        if spectral_channel:
            signal_segment = csv_data[spectral_channel].iloc[start_idx:end_idx]
            windowed_signal = signal_segment * np.hanning(len(signal_segment))
            
            fft_vals = np.fft.fft(windowed_signal)
            fft_freq = np.fft.fftfreq(len(windowed_signal), 1/sampling_rate)
            
            positive_freq_idx = (fft_freq > 0) & (fft_freq <= 50)
            frequencies = fft_freq[positive_freq_idx]
            magnitude = np.abs(fft_vals[positive_freq_idx])
            magnitude_db = 20 * np.log10(magnitude + 1e-10)
            
            fig, ax = plt.subplots(figsize=(12, 6), facecolor='white')
            
            ax.plot(frequencies, magnitude_db, color='#667eea', linewidth=2, alpha=0.8)
            ax.set_xlabel("Fréquence (Hz)", fontsize=12)
            ax.set_ylabel("Magnitude (dB)", fontsize=12)
            ax.set_title(f"Spectre de Puissance - Canal {spectral_channel}", fontsize=14)
            ax.grid(True, alpha=0.3)
            
            # Bandes de fréquences avec couleurs modernes
            bands = [
                (0.5, 4, 'Delta', '#ff6b6b'),
                (4, 8, 'Theta', '#ffa726'), 
                (8, 13, 'Alpha', '#66bb6a'),
                (13, 30, 'Beta', '#42a5f5'),
                (30, 50, 'Gamma', '#ab47bc')
            ]
            
            for low, high, name, color in bands:
                ax.axvspan(low, high, alpha=0.2, color=color, label=name)
            
            ax.legend(loc='upper right', framealpha=0.9)
            ax.set_xlim(0, 50)
            
            st.pyplot(fig)
            plt.close()
            
            # Puissance par bande
            st.markdown('<div class="section-header"><h3>⚡ Distribution de Puissance</h3></div>', unsafe_allow_html=True)
            
            band_powers = []
            total_power = np.sum(magnitude**2)
            
            for low, high, name, color in bands:
                band_idx = (frequencies >= low) & (frequencies <= high)
                if np.any(band_idx):
                    power = np.sum(magnitude[band_idx]**2)
                    percentage = power/total_power*100
                    band_powers.append({
                        'Bande': name,
                        'Plage (Hz)': f"{low}-{high}",
                        'Puissance': f"{power:.2e}",
                        'Pourcentage (%)': f"{percentage:.1f}",
                        'Couleur': color
                    })
            
            if band_powers:
                band_df = pd.DataFrame(band_powers)
                
                st.markdown('<div class="custom-card">', unsafe_allow_html=True)
                st.dataframe(band_df[['Bande', 'Plage (Hz)', 'Puissance', 'Pourcentage (%)']], use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
# Section Prédiction avec design moderne
st.markdown('<div class="section-header"><h3>🔮 Prédiction IA</h3></div>', unsafe_allow_html=True)
    
col1, col2 = st.columns(2)
with col1:
    prediction_duration = st.number_input(
            "Durée de prédiction (s)",
            min_value=1,
            max_value=60,
            value=10,
            step=1
        )
    
with col2:
        prediction_method = st.selectbox(
            "Algorithme IA",
            ["Fonction par défaut", "Modèle personnalisé", "Auto-régression", "LSTM", "Transformer"]
        )

# Section modèle personnalisé - VERSION AVEC SAISIE DE CODE
custom_model = None
if prediction_method == "Modèle personnalisé":
    st.markdown('<div class="custom-card">', unsafe_allow_html=True)
    st.markdown("#### 🤖 Chargement du Modèle IA")
    
    # Sélection du mode de chargement
    loading_mode = st.radio(
        "🔧 Mode de chargement du modèle:",
        ["📁 Charger depuis un fichier", "💻 Saisir le code directement"],
        help="Choisissez comment vous voulez charger votre modèle"
    )
    
    if loading_mode == "📁 Charger depuis un fichier":
        # Code original pour le chargement de fichier (version courte)
        model_file = st.file_uploader(
            "Déposez votre modèle entraîné",
            type=["pkl", "joblib", "h5", "keras"],
            help="Formats: pickle (.pkl), joblib (.joblib), Keras (.h5, .keras)"
        )
        
        if model_file is not None:
            try:
                # Créer le dossier temp s'il n'existe pas
                os.makedirs("temp", exist_ok=True)
                model_path = os.path.join("temp", model_file.name)
                
                with open(model_path, "wb") as f:
                    f.write(model_file.getbuffer())
                
                # Chargement selon le type de fichier
                if model_file.name.endswith('.pkl'):
                    with open(model_path, 'rb') as f:
                        custom_model = pickle.load(f)
                    st.success("✅ Modèle Pickle chargé avec succès!")
                        
                elif model_file.name.endswith('.joblib'):
                    custom_model = joblib.load(model_path)
                    st.success("✅ Modèle Joblib chargé avec succès!")
                    
                elif model_file.name.endswith(('.h5', '.keras')):
                    # Version simplifiée du chargement Keras/TensorFlow
                    try:
                        import tensorflow as tf
                        custom_model = tf.keras.models.load_model(model_path)
                        st.success("✅ Modèle TensorFlow/Keras chargé avec succès!")
                    except Exception as tf_error:
                        st.error(f"❌ Erreur TensorFlow: {tf_error}")
                        custom_model = None
                        
            except Exception as e:
                st.error(f"❌ Erreur lors du chargement: {str(e)}")
                custom_model = None
    
    elif loading_mode == "💻 Saisir le code directement":
        st.markdown("#### 📝 Définition du Modèle par Code")
        
        # Sélection du type de modèle
        model_type = st.selectbox(
            "🎯 Type de modèle:",
            [
                "TensorFlow/Keras",
                "Scikit-learn", 
                "PyTorch",
                "Modèle personnalisé (Python)"
            ],
            help="Sélectionnez le framework de votre modèle"
        )
        
        # Templates de code pré-définis
        if model_type == "TensorFlow/Keras":
            default_code = '''# Importations nécessaires
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Dense, Conv1D, Dropout, Bidirectional, Concatenate
import numpy as np

# Définition du modèle EMG/EEG
def create_model():
    # Entrées multiples
    input_seq = Input(shape=(30, 1), name='sequence_input')  # Signal temporel
    input_features = Input(shape=(11,), name='features_input')  # Caractéristiques
    
    # Traitement de la séquence
    x = Conv1D(32, 3, padding='same', activation='elu')(input_seq)
    x = LSTM(64, return_sequences=False)(x)
    x = Dropout(0.2)(x)
    
    # Traitement des caractéristiques
    features = Dense(32, activation='elu')(input_features)
    features = Dropout(0.2)(features)
    
    # Fusion
    combined = Concatenate()([x, features])
    output = Dense(1, activation='linear')(combined)
    
    # Création du modèle
    model = Model(inputs=[input_seq, input_features], outputs=output)
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    
    return model

# Créer le modèle
custom_model = create_model()'''
            
        elif model_type == "Scikit-learn":
            default_code = '''# Importations nécessaires
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
import numpy as np

# Définition du modèle
def create_model():
    # Pipeline avec preprocessing et modèle
    model = Pipeline([
        ('scaler', StandardScaler()),
        ('regressor', RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=42
        ))
    ])
    
    return model

# Créer le modèle
custom_model = create_model()

# Exemple de données d'entraînement (à remplacer par vos vraies données)
# X_train = np.random.random((1000, 10))  # 1000 échantillons, 10 features
# y_train = np.random.random(1000)
# custom_model.fit(X_train, y_train)'''
            
        elif model_type == "PyTorch":
            default_code = '''# Importations nécessaires
import torch
import torch.nn as nn
import numpy as np

# Définition du modèle PyTorch
class EMGModel(nn.Module):
    def __init__(self, sequence_length=30, n_features=11):
        super(EMGModel, self).__init__()
        
        # Couches pour la séquence temporelle
        self.conv1d = nn.Conv1d(1, 32, kernel_size=3, padding=1)
        self.lstm = nn.LSTM(32, 64, batch_first=True)
        self.dropout1 = nn.Dropout(0.2)
        
        # Couches pour les caractéristiques
        self.fc_features = nn.Linear(n_features, 32)
        self.dropout2 = nn.Dropout(0.2)
        
        # Couche de sortie
        self.fc_out = nn.Linear(64 + 32, 1)
        
    def forward(self, sequence, features):
        # Traitement de la séquence
        x = torch.relu(self.conv1d(sequence.transpose(1, 2)))
        x = x.transpose(1, 2)
        x, _ = self.lstm(x)
        x = self.dropout1(x[:, -1, :])  # Prendre la dernière sortie
        
        # Traitement des caractéristiques
        f = torch.relu(self.fc_features(features))
        f = self.dropout2(f)
        
        # Fusion et sortie
        combined = torch.cat([x, f], dim=1)
        output = self.fc_out(combined)
        
        return output

# Créer le modèle
custom_model = EMGModel()
custom_model.eval()  # Mode évaluation'''
            
        else:  # Modèle personnalisé
            default_code = '''# Modèle personnalisé Python
import numpy as np
from typing import Union, List

class CustomModel:
    """
    Modèle personnalisé pour prédiction EMG/EEG
    Adaptez cette classe selon vos besoins
    """
    
    def __init__(self):
        self.is_trained = False
        self.model_params = {}
        
    def fit(self, X, y):
        """Entraîner le modèle"""
        # Votre logique d'entraînement ici
        self.is_trained = True
        return self
        
    def predict(self, X):
        """Faire des prédictions"""
        if not self.is_trained:
            raise ValueError("Le modèle doit être entraîné avant de faire des prédictions")
        
        # Exemple simple: moyenne mobile
        if isinstance(X, list) and len(X) == 2:
            # Pour les entrées multiples [sequence, features]
            sequence, features = X
            # Logique de prédiction personnalisée
            prediction = np.mean(sequence, axis=1, keepdims=True) + np.mean(features, axis=1, keepdims=True)
        else:
            # Pour une seule entrée
            prediction = np.mean(X, axis=1, keepdims=True)
            
        return prediction
    
    def score(self, X, y):
        """Évaluer le modèle"""
        predictions = self.predict(X)
        mse = np.mean((predictions - y) ** 2)
        return 1 - mse  # Score simplifié

# Créer et "entraîner" le modèle
custom_model = CustomModel()
# custom_model.fit(X_train, y_train)  # Décommentez si vous avez des données'''

        # Éditeur de code avec coloration syntaxique
        st.markdown("##### ✏️ Éditeur de Code")
        
        # Options d'édition
        col1, col2 = st.columns([3, 1])
        with col1:
            use_template = st.checkbox("📋 Utiliser le template", value=True, 
                                     help="Commencer avec un template pré-défini")
        with col2:
            if st.button("🔄 Réinitialiser"):
                st.session_state.pop('model_code', None)
                st.rerun()
        
        # Éditeur de code
        if use_template and 'model_code' not in st.session_state:
            st.session_state.model_code = default_code
        elif not use_template and 'model_code' not in st.session_state:
            st.session_state.model_code = "# Écrivez votre code de modèle ici\n"
        
        model_code = st.text_area(
            "💻 Code du modèle:",
            value=st.session_state.get('model_code', default_code if use_template else "# Écrivez votre code de modèle ici\n"),
            height=400,
            help="Écrivez ou collez le code de définition de votre modèle",
            key='model_code_editor'
        )
        
        # Mise à jour du code en session
        st.session_state.model_code = model_code
        
        # Options d'exécution
        col1, col2, col3 = st.columns(3)
        with col1:
            validate_syntax = st.checkbox("🔍 Vérification syntaxe", value=True)
        with col2:
            show_imports = st.checkbox("📦 Vérifier imports", value=True)
        with col3:
            safe_mode = st.checkbox("🛡️ Mode sécurisé", value=True, 
                                  help="Empêche l'exécution de code potentiellement dangereux")
        
        # Bouton d'exécution
        if st.button("🚀 Créer le Modèle", type="primary"):
            try:
                # Vérification syntaxique
                if validate_syntax:
                    try:
                        compile(model_code, '<string>', 'exec')
                        st.success("✅ Syntaxe valide")
                    except SyntaxError as e:
                        st.error(f"❌ Erreur de syntaxe: {e}")
                        st.stop()
                
                # Vérification des imports (mode sécurisé)
                if safe_mode:
                    dangerous_keywords = ['os.system', 'subprocess', 'eval', 'exec', '__import__', 'open(', 'file(']
                    for keyword in dangerous_keywords:
                        if keyword in model_code:
                            st.error(f"❌ Code potentiellement dangereux détecté: {keyword}")
                            st.warning("Désactivez le mode sécurisé si vous êtes sûr de votre code")
                            st.stop()
                
                # Vérification des imports
                if show_imports:
                    import_lines = [line.strip() for line in model_code.split('\n') 
                                  if line.strip().startswith(('import ', 'from '))]
                    if import_lines:
                        st.info("📦 Imports détectés:")
                        for imp in import_lines:
                            st.code(imp, language='python')
                
                # Exécution du code
                with st.spinner("🔄 Création du modèle en cours..."):
                    # Créer un namespace local pour l'exécution
                    local_namespace = {
                        '__builtins__': __builtins__,
                        'np': np,  # numpy est généralement disponible
                    }
                    
                    # Essayer d'importer les bibliothèques communes
                    try:
                        import tensorflow as tf
                        local_namespace['tf'] = tf
                        local_namespace['tensorflow'] = tf
                    except ImportError:
                        pass
                    
                    try:
                        import torch
                        import torch.nn as nn
                        local_namespace['torch'] = torch
                        local_namespace['nn'] = nn
                    except ImportError:
                        pass
                    
                    try:
                        from sklearn.ensemble import RandomForestRegressor
                        from sklearn.linear_model import LinearRegression
                        from sklearn.pipeline import Pipeline
                        from sklearn.preprocessing import StandardScaler
                        import sklearn
                        local_namespace['sklearn'] = sklearn
                        local_namespace['RandomForestRegressor'] = RandomForestRegressor
                        local_namespace['LinearRegression'] = LinearRegression
                        local_namespace['Pipeline'] = Pipeline
                        local_namespace['StandardScaler'] = StandardScaler
                    except ImportError:
                        pass
                    
                    # Exécuter le code
                    exec(model_code, local_namespace)
                    
                    # Récupérer le modèle créé
                    if 'custom_model' in local_namespace:
                        custom_model = local_namespace['custom_model']
                        st.success("✅ Modèle créé avec succès!")
                        
                        # Afficher le type de modèle
                        model_type_name = type(custom_model).__name__
                        st.info(f"🎯 Type de modèle: {model_type_name}")
                        
                    else:
                        st.error("❌ Aucune variable 'custom_model' trouvée dans le code")
                        st.info("💡 Assurez-vous que votre code définit une variable nommée 'custom_model'")
                        custom_model = None
            
            except Exception as e:
                st.error(f"❌ Erreur lors de l'exécution: {str(e)}")
                
                # Afficher plus de détails sur l'erreur
                with st.expander("🔧 Détails de l'erreur"):
                    import traceback
                    st.code(traceback.format_exc(), language='text')
                    
                    st.markdown("""
                    **Solutions possibles:**
                    - Vérifiez que toutes les bibliothèques nécessaires sont installées
                    - Assurez-vous que la variable 'custom_model' est bien définie
                    - Testez votre code dans un environnement Python local d'abord
                    - Désactivez le mode sécurisé si nécessaire
                    """)
                
                custom_model = None
        
        # Aide et exemples
        with st.expander("💡 Aide et Exemples"):
            st.markdown("""
            ### 📚 Guide d'utilisation
            
            **Structure requise:**
            1. Votre code doit créer une variable nommée `custom_model`
            2. Le modèle doit avoir une méthode `predict()` qui accepte vos données
            3. Pour les modèles à entrées multiples, `predict()` doit accepter une liste [sequence, features]
            
            **Exemples d'usage:**
            """)
            
            tab1, tab2, tab3 = st.tabs(["TensorFlow", "Scikit-learn", "PyTorch"])
            
            with tab1:
                st.code('''
# Modèle TensorFlow simple
import tensorflow as tf

model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=(10,)),
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(1)
])

model.compile(optimizer='adam', loss='mse')
custom_model = model
                ''', language='python')
            
            with tab2:
                st.code('''
# Modèle Scikit-learn
from sklearn.ensemble import RandomForestRegressor

custom_model = RandomForestRegressor(n_estimators=100, random_state=42)
# Note: Le modèle doit être entraîné pour faire des prédictions
                ''', language='python')
            
            with tab3:
                st.code('''
# Modèle PyTorch
import torch
import torch.nn as nn

class SimpleModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(10, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )
    
    def forward(self, x):
        return self.layers(x)
    
    def predict(self, x):
        self.eval()
        with torch.no_grad():
            if isinstance(x, np.ndarray):
                x = torch.FloatTensor(x)
            return self.forward(x).numpy()

custom_model = SimpleModel()
                ''', language='python')
    
    # Section d'informations du modèle (commune aux deux modes)
    if custom_model is not None:
        st.markdown("---")
        st.markdown("### 📋 Informations du Modèle")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            model_type_display = type(custom_model).__name__
            st.metric("Type", model_type_display)
        
        with col2:
            # Compter les paramètres si possible
            param_count = "N/A"
            try:
                if hasattr(custom_model, 'count_params'):
                    param_count = f"{custom_model.count_params():,}"
                elif hasattr(custom_model, 'parameters'):
                    # PyTorch
                    total_params = sum(p.numel() for p in custom_model.parameters())
                    param_count = f"{total_params:,}"
                elif hasattr(custom_model, 'get_params'):
                    # Scikit-learn
                    param_count = "Sklearn"
            except:
                pass
            st.metric("Paramètres", param_count)
        
        with col3:
            # Statut du modèle
            status = "✅ Chargé"
            if hasattr(custom_model, 'is_trained'):
                status = "✅ Entraîné" if custom_model.is_trained else "⚠️ Non entraîné"
            st.metric("Statut", status)
        
        # Test de prédiction
        with st.expander("🧪 Test du Modèle"):
            if st.button("Tester une prédiction"):
                try:
                    # Créer des données de test factices
                    if hasattr(custom_model, 'input') and hasattr(custom_model.input, '__iter__'):
                        # Modèle TensorFlow à entrées multiples
                        test_inputs = []
                        for i, input_layer in enumerate(custom_model.input):
                            shape = list(input_layer.shape)
                            shape[0] = 1  # batch_size = 1
                            test_data = np.random.random(shape)
                            test_inputs.append(test_data)
                        
                        test_pred = custom_model.predict(test_inputs)
                        st.success(f"✅ Test réussi! Prédiction: {test_pred}")
                        
                    else:
                        # Test avec des données factices simples
                        test_data = np.random.random((1, 10))  # 1 échantillon, 10 features
                        
                        if hasattr(custom_model, 'predict'):
                            test_pred = custom_model.predict(test_data)
                            st.success(f"✅ Test réussi! Prédiction: {test_pred}")
                        else:
                            st.error("❌ Le modèle n'a pas de méthode 'predict'")
                            
                except Exception as test_error:
                    st.error(f"❌ Test échoué: {test_error}")
                    st.info("💡 Le modèle peut nécessiter un format de données spécifique")
        
        # Sauvegarde du code
        if loading_mode == "💻 Saisir le code directement":
            with st.expander("💾 Sauvegarder le Code"):
                st.download_button(
                    label="📥 Télécharger le code du modèle",
                    data=model_code,
                    file_name="custom_model.py",
                    mime="text/plain"
                )
    
    st.markdown('</div>', unsafe_allow_html=True)
    #options avancees
    with st.expander("🔧 Options Avancées"):
        use_preprocessing = st.checkbox("Appliquer un prétraitement supplémentaire", value=True)
        filter_signals = st.checkbox("Filtrer les signaux", value=True)
        if filter_signals:
            col1, col2 = st.columns(2)
            with col1:
                low_freq = st.number_input("Fréquence basse (Hz)", value=0.5, step=0.1)
            with col2:
                high_freq = st.number_input("Fréquence haute (Hz)", value=50.0, step=0.1)
        
        # Options de sauvegarde
        st.markdown("### 💾 Options de Sauvegarde")
        save_predictions = st.checkbox("Sauvegarder les prédictions en CSV", value=True)
        if save_predictions:
            csv_filename = st.text_input(
                "Nom du fichier CSV de prédictions",
                value=f"predictions_{uploaded_file.name.split('.')[0]}.csv"
            )
    
    # Fonction personnalisée de prédiction avec modèle utilisateur
    def predict_with_custom_model(data, model, sampling_rate):
        """
        Fonction de prédiction utilisant un modèle personnalisé
        """
        try:
            if data is None or len(data) == 0:
                st.error("Aucune donnée fournie pour la prédiction")
                return None, None
            # Extraire les colonnes EEG et EMG si elles existent
            eeg_columns = [col for col in data.columns if 'EEG Fpz-Cz' in col ]
            emg_columns = [col for col in data.columns if 'EMG submental' in col]
            # Préparer les données pour la prédiction
            n_samples_pred = int(prediction_duration * sampling_rate)
            if model is not None and hasattr(model, 'predict'):
                try:
                    # Préparer les features (dernières valeurs)
                    n_features = min(100, len(data))
                    if eeg_columns:
                        eeg_data = data[eeg_columns].iloc[-n_features:].values.flatten()
                        X_eeg = eeg_data.reshape(1, -1)
                        eeg_predictions = model.predict(X_eeg)
                        # Générer la séquence prédite basée sur le modèle
                        if hasattr(eeg_predictions, '__len__') and len(eeg_predictions) > 0:
                            base_eeg = eeg_predictions[0] if hasattr(eeg_predictions[0], '__len__') else eeg_predictions[0]
                            # Créer une variation réaliste autour de la prédiction
                            eeg_pred = np.random.normal(base_eeg, np.std(data[eeg_columns[0]]) * 0.1, n_samples_pred)
                        else:
                            eeg_pred = np.zeros(n_samples_pred)
                    else:
                        eeg_pred = np.zeros(n_samples_pred)
                    if emg_columns:
                        emg_data = data[emg_columns].iloc[-n_features:].values.flatten()
                        X_emg = emg_data.reshape(1, -1)
                        emg_predictions = model.predict(X_emg)
                        if hasattr(emg_predictions, '__len__') and len(emg_predictions) > 0:
                             base_emg = emg_predictions[0] if hasattr(emg_predictions[0], '__len__') else emg_predictions[0]
                             emg_pred = np.random.normal(base_emg, np.std(data[emg_columns[0]]) * 0.1, n_samples_pred)
                        else:
                            emg_pred = np.zeros(n_samples_pred)
                    else:
                        emg_pred = np.zeros(n_samples_pred)
                except Exception as e:
                    st.warning(f"Erreur avec le modèle, utilisation de l'extrapolation: {str(e)}")
            return eeg_pred, emg_pred
        except Exception as e:
            st.error(f"Erreur lors de la prédiction avec le modèle personnalisé: {str(e)}")
            return None, None
     
    # Bouton de prédiction
    if st.button("🚀 Lancer la Prédiction", type="primary"):
        with st.spinner("🤖 Prédiction en cours..."):
            try:
                # Sélection de la méthode de prédiction
                if prediction_method == "Modèle personnalisé" and custom_model is not None:
                    eeg_pred, emg_pred = predict_with_custom_model(csv_data, custom_model, sampling_rate)
                else:
                    # Utilisation de la fonction par défaut
                    eeg_pred, emg_pred = predict_signals(csv_data, sampling_rate)
                
                if eeg_pred is not None or emg_pred is not None:
                    st.success("✅ Prédiction terminée avec succès !")
                    
                    # Sauvegarde des prédictions si demandée
                    if save_predictions and (eeg_pred is not None or emg_pred is not None):
                        predictions_df = pd.DataFrame()
                        
                        # Créer un vecteur temps
                        if eeg_pred is not None and emg_pred is not None:
                            max_len = max(len(eeg_pred), len(emg_pred))
                        elif eeg_pred is not None:
                            max_len = len(eeg_pred)
                        else:
                            max_len = len(emg_pred)
                        
                        predictions_df['Temps_s'] = np.arange(max_len) / sampling_rate
                        
                        if eeg_pred is not None:
                            # Ajuster la longueur si nécessaire
                            if len(eeg_pred) < max_len:
                                eeg_extended = np.pad(eeg_pred, (0, max_len - len(eeg_pred)), mode='constant')
                            else:
                                eeg_extended = eeg_pred[:max_len]
                            predictions_df['EEG_Prediction'] = eeg_extended
                        
                        if emg_pred is not None:
                            # Ajuster la longueur si nécessaire
                            if len(emg_pred) < max_len:
                                emg_extended = np.pad(emg_pred, (0, max_len - len(emg_pred)), mode='constant')
                            else:
                                emg_extended = emg_pred[:max_len]
                            predictions_df['EMG_Prediction'] = emg_extended
                        
                        # Ajout des métadonnées
                        predictions_df['Methode_Prediction'] = prediction_method
                        predictions_df['Frequence_Echantillonnage'] = sampling_rate
                        predictions_df['Duree_Prediction_s'] = prediction_duration
                        
                        # Sauvegarde
                        predictions_path = os.path.join("temp", csv_filename)
                        os.makedirs("temp", exist_ok=True)
                        predictions_df.to_csv(predictions_path, index=False)
                        
                        st.success(f"✅ Prédictions sauvegardées dans {csv_filename}")
                        
                        # Bouton de téléchargement
                        with open(predictions_path, 'rb') as f:
                            st.download_button(
                                label="📥 Télécharger le fichier de prédictions",
                                data=f.read(),
                                file_name=csv_filename,
                                mime="text/csv"
                            )
                else:
                    st.error("❌ Aucune prédiction générée")
                

                
            except Exception as e:
                st.error(f"❌ Erreur lors de la prédiction : {str(e)}")
                st.write("Détails de l'erreur :", str(e))
    
    # Section de téléchargement des résultats
    st.markdown('<div class="section-header"><h3>🔮 Telechargements des resultats</h3></div>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        # Option pour télécharger les données CSV prétraitées
        if st.button("📥 Télécharger données prétraitées"):
            csv_string = csv_data.to_csv(index=False)
            st.download_button(
                label="💾 Télécharger CSV prétraité",
                data=csv_string,
                file_name=f"donnees_pretraitees_{uploaded_file.name.split('.')[0]}.csv",
                mime="text/csv"
            )
    
    with col2:
        # Option pour télécharger les données originales
        if st.button("📥 Télécharger données originales"):
            # Recharger les données originales
            original_data, _ = convert_edf_to_csv(edf_path)
            csv_string = original_data.to_csv(index=False)
            st.download_button(
                label="💾 Télécharger CSV original",
                data=csv_string,
                file_name=f"donnees_originales_{uploaded_file.name.split('.')[0]}.csv",
                mime="text/csv"
            )
    
    with col3:
        # Option pour télécharger le rapport
        if st.button("📄 Générer rapport complet"):
            # Calcul des statistiques de prétraitement
            preprocessing_stats = "\n".join(preprocessing_info) if preprocessing_info else "Aucun prétraitement appliqué"
            
            report = f"""
# Rapport d'Analyse du Sommeil - Complet

## Informations du fichier
- Nom du fichier : {uploaded_file.name}
- Nombre d'échantillons original : {len(csv_data)}
- Fréquence d'échantillonnage : {sampling_rate} Hz
- Nombre de canaux : {len(csv_data.columns)}
- Canaux disponibles : {', '.join(csv_data.columns.tolist())}

## Prétraitement appliqué
{preprocessing_stats}

## Statistiques des données prétraitées
- Durée totale : {len(csv_data)/sampling_rate:.2f} secondes
- Période analysée : {start_time}s à {start_time + duration_seconds}s
- Canaux analysés : {', '.join(selected_channels) if selected_channels else 'Aucun canal sélectionné'}

## Paramètres de prédiction
- Méthode utilisée : {prediction_method}
- Durée de prédiction : {prediction_duration} secondes

## Résumé des analyses
- Visualisation temporelle : ✅
- Analyse spectrale : ✅ (Canal: {spectral_channel if 'spectral_channel' in locals() else 'N/A'})
- Prédiction EEG/EMG : {'✅' if prediction_method else '❌'}

---
Rapport généré le {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
Application d'Analyse du Sommeil v2.0
            """
            
            st.download_button(
                label="📄 Télécharger rapport complet",
                data=report,
                file_name=f"rapport_complet_{uploaded_file.name.split('.')[0]}.md",
                mime="text/markdown"
            )

else:
    # Page d'accueil quand aucun fichier n'est chargé
    st.info("👋 Bienvenue dans l'application d'analyse du sommeil !")
# Fonction de détection des troubles du sommeil
def detect_sleep_disorders(eeg_data, emg_data, sampling_rate, duration_minutes=None):
    """
    Détecte les troubles du sommeil basés sur l'analyse des signaux EEG/EMG
    
    Parameters:
    - eeg_data: signal EEG
    - emg_data: signal EMG  
    - sampling_rate: fréquence d'échantillonnage
    - duration_minutes: durée d'enregistrement en minutes
    
    Returns:
    - dict avec les résultats de détection
    """
    
    results = {
        'apnee': {'detected': False, 'severity': 'Normal', 'episodes': 0, 'confidence': 0},
        'insomnie': {'detected': False, 'severity': 'Normal', 'wake_periods': 0, 'confidence': 0},
        'narcolepsie': {'detected': False, 'severity': 'Normal', 'rem_episodes': 0, 'confidence': 0}
    }
    
    try:
        # Calculs de base
        total_duration = len(eeg_data) / sampling_rate  # en secondes
        
        # === DÉTECTION APNÉE DU SOMMEIL ===
        # Analyse des variations respiratoires via EMG et EEG
        if emg_data is not None and len(emg_data) > 0:
            # Filtrage pour isoler les patterns respiratoires (0.1-0.5 Hz)
            from scipy import signal as scipy_signal
            
            # Filtre passe-bas pour EMG (activité respiratoire)
            sos_low = scipy_signal.butter(4, 0.5, btype='low', fs=sampling_rate, output='sos')
            emg_filtered = scipy_signal.sosfilt(sos_low, emg_data)
            
            # Détection des pauses respiratoires (amplitude très faible)
            window_size = int(10 * sampling_rate)  # fenêtre de 10 secondes
            apnea_threshold = np.std(emg_filtered) * 0.3  # seuil d'apnée
            
            apnea_episodes = 0
            i = 0
            while i < len(emg_filtered) - window_size:
                window = emg_filtered[i:i+window_size]
                if np.mean(np.abs(window)) < apnea_threshold:
                    apnea_episodes += 1
                    i += window_size  # éviter le double comptage
                else:
                    i += window_size // 4
            
            # Classification selon l'AHI (Apnea-Hypopnea Index)
            if duration_minutes is None:
                duration_minutes = total_duration / 60
            
            ahi = apnea_episodes / (duration_minutes / 60) if duration_minutes > 0 else 0
            
            if ahi >= 30:
                results['apnee'] = {'detected': True, 'severity': 'Sévère', 'episodes': apnea_episodes, 'confidence': 0.85}
            elif ahi >= 15:
                results['apnee'] = {'detected': True, 'severity': 'Modérée', 'episodes': apnea_episodes, 'confidence': 0.75}
            elif ahi >= 5:
                results['apnee'] = {'detected': True, 'severity': 'Légère', 'episodes': apnea_episodes, 'confidence': 0.65}
            else:
                results['apnee'] = {'detected': False, 'severity': 'Normal', 'episodes': apnea_episodes, 'confidence': 0.9}
        
        # === DÉTECTION INSOMNIE ===
        # Analyse des micro-réveils via activité EEG
        if eeg_data is not None and len(eeg_data) > 0:
            # Filtre pour les ondes beta (13-30 Hz) - indicateur d'éveil
            sos_beta = scipy_signal.butter(4, [13, 30], btype='band', fs=sampling_rate, output='sos')
            eeg_beta = scipy_signal.sosfilt(sos_beta, eeg_data)
            
            # Filtre pour les ondes alpha (8-13 Hz) - transition éveil/sommeil
            sos_alpha = scipy_signal.butter(4, [8, 13], btype='band', fs=sampling_rate, output='sos')
            eeg_alpha = scipy_signal.sosfilt(sos_alpha, eeg_data)
            
            # Détection des périodes d'éveil (forte activité beta + alpha)
            window_size = int(30 * sampling_rate)  # fenêtre de 30 secondes
            wake_threshold = np.percentile(np.abs(eeg_beta), 75)  # seuil adaptatif
            
            wake_periods = 0
            total_wake_time = 0
            
            for i in range(0, len(eeg_beta) - window_size, window_size):
                beta_window = eeg_beta[i:i+window_size]
                alpha_window = eeg_alpha[i:i+window_size]
                
                beta_power = np.mean(np.abs(beta_window))
                alpha_power = np.mean(np.abs(alpha_window))
                
                # Critères d'éveil: forte activité beta ET alpha
                if beta_power > wake_threshold and alpha_power > wake_threshold * 0.7:
                    wake_periods += 1
                    total_wake_time += 30  # 30 secondes
            
            # Pourcentage de temps éveillé
            wake_percentage = (total_wake_time / total_duration) * 100
            
            if wake_percentage > 25:  # Plus de 25% éveillé
                results['insomnie'] = {'detected': True, 'severity': 'Sévère', 'wake_periods': wake_periods, 'confidence': 0.8}
            elif wake_percentage > 15:
                results['insomnie'] = {'detected': True, 'severity': 'Modérée', 'wake_periods': wake_periods, 'confidence': 0.7}
            elif wake_percentage > 8:
                results['insomnie'] = {'detected': True, 'severity': 'Légère', 'wake_periods': wake_periods, 'confidence': 0.6}
            else:
                results['insomnie'] = {'detected': False, 'severity': 'Normal', 'wake_periods': wake_periods, 'confidence': 0.85}
        
        # === DÉTECTION NARCOLEPSIE ===
        # Analyse des transitions REM anormales
        if eeg_data is not None and emg_data is not None:
            # Filtre pour les ondes theta (4-8 Hz) - caractéristiques du REM
            sos_theta = scipy_signal.butter(4, [4, 8], btype='band', fs=sampling_rate, output='sos')
            eeg_theta = scipy_signal.sosfilt(sos_theta, eeg_data)
            
            # Détection des épisodes REM (theta élevé + EMG faible)
            window_size = int(60 * sampling_rate)  # fenêtre de 1 minute
            
            theta_threshold = np.percentile(np.abs(eeg_theta), 70)
            emg_threshold = np.percentile(np.abs(emg_data), 30)
            
            rem_episodes = 0
            rapid_rem_transitions = 0
            
            for i in range(0, len(eeg_theta) - window_size, window_size):
                theta_window = eeg_theta[i:i+window_size]
                emg_window = emg_data[i:i+window_size]
                
                theta_power = np.mean(np.abs(theta_window))
                emg_power = np.mean(np.abs(emg_window))
                
                # Critères REM: theta élevé ET EMG faible
                if theta_power > theta_threshold and emg_power < emg_threshold:
                    rem_episodes += 1
                    
                    # Vérifier si c'est une transition rapide vers REM (< 15 min du début)
                    time_minutes = (i / sampling_rate) / 60
                    if time_minutes < 15:  # REM précoce (indicateur de narcolepsie)
                        rapid_rem_transitions += 1
            
            # Analyse des patterns anormaux
            total_hours = total_duration / 3600
            rem_density = rem_episodes / total_hours if total_hours > 0 else 0
            
            # Critères narcolepsie: REM précoce + densité REM élevée
            if rapid_rem_transitions >= 2 and rem_density > 4:
                results['narcolepsie'] = {'detected': True, 'severity': 'Sévère', 'rem_episodes': rem_episodes, 'confidence': 0.75}
            elif rapid_rem_transitions >= 1 and rem_density > 3:
                results['narcolepsie'] = {'detected': True, 'severity': 'Modérée', 'rem_episodes': rem_episodes, 'confidence': 0.65}
            elif rapid_rem_transitions >= 1 or rem_density > 2.5:
                results['narcolepsie'] = {'detected': True, 'severity': 'Légère', 'rem_episodes': rem_episodes, 'confidence': 0.55}
            else:
                results['narcolepsie'] = {'detected': False, 'severity': 'Normal', 'rem_episodes': rem_episodes, 'confidence': 0.8}
        
    except Exception as e:
        st.error(f"Erreur dans la détection des troubles: {str(e)}")
    
    return results

# Interface utilisateur pour la détection des troubles
st.markdown('<div class="section-header"><h3>🩺 Détection des Troubles du Sommeil</h3></div>', unsafe_allow_html=True)

# Installation scipy si nécessaire
try:
    from scipy import signal as scipy_signal
except ImportError:
    st.error("📦 Le module scipy est requis pour la détection des troubles. Installez-le avec: pip install scipy")
    st.stop()

# Sélection des canaux pour analyse - CORRECTION: Vérifier que csv_data et available_channels existent
if 'csv_data' in locals() and csv_data is not None:
    # Récupérer les colonnes disponibles
    available_channels = csv_data.columns.tolist()
    
    st.markdown('<div class="custom-card">', unsafe_allow_html=True)
    st.markdown("#### 🔧 Configuration de l'Analyse")

    col1, col2 = st.columns(2)
    with col1:
        eeg_channel = st.selectbox(
            "Canal EEG à analyser",
            available_channels,
            help="Sélectionnez le canal contenant les signaux EEG"
        )

    with col2:
        emg_channel = st.selectbox(
            "Canal EMG à analyser", 
            available_channels,
            index=min(1, len(available_channels)-1) if len(available_channels) > 1 else 0,
            help="Sélectionnez le canal contenant les signaux EMG"
        )

    # Paramètres avancés
    with st.expander("⚙️ Paramètres Avancés de Détection"):
        col1, col2 = st.columns(2)
        with col1:
            duration_input = st.number_input(
                "Durée d'enregistrement (minutes)",
                min_value=1,
                max_value=2000,
                value=int((len(csv_data) / sampling_rate) / 60) if 'sampling_rate' in locals() else 60,
                help="Durée totale de l'enregistrement pour calculer les indices"
            )
        
        with col2:
            sensitivity = st.selectbox(
                "Sensibilité de détection",
                ["Faible", "Normale", "Élevée"],
                index=1,
                help="Ajuste les seuils de détection"
            )

    st.markdown('</div>', unsafe_allow_html=True)

    # Bouton de détection
    if st.button("🔍 Analyser les Troubles du Sommeil", type="primary"):
        with st.spinner("🧠 Analyse des troubles en cours..."):
            
            # Récupération des données des canaux sélectionnés
            eeg_data = csv_data[eeg_channel].values if eeg_channel in csv_data.columns else None
            emg_data = csv_data[emg_channel].values if emg_channel in csv_data.columns else None
            
            if eeg_data is None or emg_data is None:
                st.error("❌ Impossible de récupérer les données des canaux sélectionnés")
            else:
                # Lancer la détection
                disorder_results = detect_sleep_disorders(
                    eeg_data, emg_data, sampling_rate, duration_input
                )
                
                # Affichage des résultats
                st.markdown('<div class="section-header"><h3>📋 Résultats de Diagnostic</h3></div>', unsafe_allow_html=True)
                
                # Créer trois colonnes pour les trois troubles
                col1, col2, col3 = st.columns(3)
                
                # APNÉE DU SOMMEIL
                with col1:
                    apnee = disorder_results['apnee']
                    
                    if apnee['detected']:
                        if apnee['severity'] == 'Sévère':
                            color = "#ff4444"
                            icon = "🚨"
                        elif apnee['severity'] == 'Modérée':
                            color = "#ff8800"
                            icon = "⚠️"
                        else:
                            color = "#ffaa00"
                            icon = "⚡"
                    else:
                        color = "#44aa44"
                        icon = "✅"
                    
                    st.markdown(f"""
                    <div class="custom-card" style="border-left: 4px solid {color};">
                        <h4>{icon} Apnée du Sommeil</h4>
                        <p><strong>État:</strong> {apnee['severity']}</p>
                        <p><strong>Épisodes détectés:</strong> {apnee['episodes']}</p>
                        <p><strong>Confiance:</strong> {apnee['confidence']*100:.1f}%</p>
                        {'<p style="color: red;"><strong>⚠️ Consultation recommandée</strong></p>' if apnee['detected'] else '<p style="color: green;"><strong>✅ Aucun signe détecté</strong></p>'}
                    </div>
                    """, unsafe_allow_html=True)
                
                # INSOMNIE
                with col2:
                    insomnie = disorder_results['insomnie']
                    
                    if insomnie['detected']:
                        if insomnie['severity'] == 'Sévère':
                            color = "#ff4444"
                            icon = "😴"
                        elif insomnie['severity'] == 'Modérée':
                            color = "#ff8800"
                            icon = "💤"
                        else:
                            color = "#ffaa00"
                            icon = "😑"
                    else:
                        color = "#44aa44"
                        icon = "😊"
                    
                    st.markdown(f"""
                    <div class="custom-card" style="border-left: 4px solid {color};">
                        <h4>{icon} Insomnie</h4>
                        <p><strong>État:</strong> {insomnie['severity']}</p>
                        <p><strong>Périodes d'éveil:</strong> {insomnie['wake_periods']}</p>
                        <p><strong>Confiance:</strong> {insomnie['confidence']*100:.1f}%</p>
                        {'<p style="color: red;"><strong>⚠️ Troubles du sommeil détectés</strong></p>' if insomnie['detected'] else '<p style="color: green;"><strong>✅ Sommeil de qualité</strong></p>'}
                    </div>
                    """, unsafe_allow_html=True)
                
                # NARCOLEPSIE
                with col3:
                    narcolepsie = disorder_results['narcolepsie']
                    
                    if narcolepsie['detected']:
                        if narcolepsie['severity'] == 'Sévère':
                            color = "#ff4444"
                            icon = "🌙"
                        elif narcolepsie['severity'] == 'Modérée':
                            color = "#ff8800"
                            icon = "🌛"
                        else:
                            color = "#ffaa00"
                            icon = "🌜"
                    else:
                        color = "#44aa44"
                        icon = "🌞"
                    
                    st.markdown(f"""
                    <div class="custom-card" style="border-left: 4px solid {color};">
                        <h4>{icon} Narcolepsie</h4>
                        <p><strong>État:</strong> {narcolepsie['severity']}</p>
                        <p><strong>Épisodes REM:</strong> {narcolepsie['rem_episodes']}</p>
                        <p><strong>Confiance:</strong> {narcolepsie['confidence']*100:.1f}%</p>
                        {'<p style="color: red;"><strong>⚠️ Patterns anormaux détectés</strong></p>' if narcolepsie['detected'] else '<p style="color: green;"><strong>✅ Cycles de sommeil normaux</strong></p>'}
                    </div>
                    """, unsafe_allow_html=True)
                
                # Résumé global
                st.markdown('<div class="section-header"><h3>📊 Résumé Diagnostique</h3></div>', unsafe_allow_html=True)
                
                total_disorders = sum([1 for d in disorder_results.values() if d['detected']])
                
                if total_disorders == 0:
                    st.success("🎉 Aucun trouble majeur du sommeil détecté ! Votre sommeil semble de bonne qualité.")
                elif total_disorders == 1:
                    st.warning("⚠️ Un trouble du sommeil potentiel détecté. Consultez un spécialiste pour confirmation.")
                else:
                    st.error("🚨 Plusieurs troubles du sommeil détectés. Une consultation médicale est fortement recommandée.")
                
                # Graphique de visualisation des troubles
                st.markdown('<div class="section-header"><h3>📈 Visualisation des Troubles</h3></div>', unsafe_allow_html=True)
                
                # Créer un graphique en barres des sévérités
                disorders = ['Apnée', 'Insomnie', 'Narcolepsie']
                severities = [
                    3 if disorder_results['apnee']['severity'] == 'Sévère' else 
                    2 if disorder_results['apnee']['severity'] == 'Modérée' else 
                    1 if disorder_results['apnee']['severity'] == 'Légère' else 0,
                    
                    3 if disorder_results['insomnie']['severity'] == 'Sévère' else 
                    2 if disorder_results['insomnie']['severity'] == 'Modérée' else 
                    1 if disorder_results['insomnie']['severity'] == 'Légère' else 0,
                    
                    3 if disorder_results['narcolepsie']['severity'] == 'Sévère' else 
                    2 if disorder_results['narcolepsie']['severity'] == 'Modérée' else 
                    1 if disorder_results['narcolepsie']['severity'] == 'Légère' else 0
                ]
                
                colors = ['#ff4444' if s == 3 else '#ff8800' if s == 2 else '#ffaa00' if s == 1 else '#44aa44' for s in severities]
                
                fig, ax = plt.subplots(figsize=(10, 6))
                bars = ax.bar(disorders, severities, color=colors, alpha=0.8)
                
                ax.set_ylabel('Niveau de Sévérité')
                ax.set_title('Évaluation des Troubles du Sommeil')
                ax.set_ylim(0, 3.5)
                ax.set_yticks([0, 1, 2, 3])
                ax.set_yticklabels(['Normal', 'Léger', 'Modéré', 'Sévère'])
                ax.grid(True, alpha=0.3)
                
                # Ajouter les valeurs sur les barres
                for bar, severity in zip(bars, severities):
                    if severity > 0:
                        height = bar.get_height()
                        ax.text(bar.get_x() + bar.get_width()/2., height + 0.05,
                               ['', 'Léger', 'Modéré', 'Sévère'][int(severity)],
                               ha='center', va='bottom', fontweight='bold')
                
                st.pyplot(fig)
                plt.close()
                
                # Recommandations
                st.markdown('<div class="section-header"><h3>💡 Recommandations</h3></div>', unsafe_allow_html=True)
                
                recommendations = []
                
                if disorder_results['apnee']['detected']:
                    recommendations.append("🫁 **Apnée du sommeil**: Consultez un pneumologue ou spécialiste du sommeil. Évitez l'alcool le soir et dormez sur le côté.")
                
                if disorder_results['insomnie']['detected']:
                    recommendations.append("😴 **Insomnie**: Établissez une routine de sommeil régulière. Évitez les écrans 1h avant le coucher.")
                
                if disorder_results['narcolepsie']['detected']:
                    recommendations.append("🧠 **Narcolepsie**: Consultez un neurologue spécialisé. Planifiez des siestes courtes dans la journée.")
                
                if not recommendations:
                    recommendations.append("✅ **Sommeil sain**: Maintenez vos bonnes habitudes de sommeil !")
                
                for rec in recommendations:
                    st.markdown(f"- {rec}")
                
                # Export des résultats
                st.markdown('<div class="section-header"><h3>💾 Export des Résultats</h3></div>', unsafe_allow_html=True)
                
                # Créer un rapport détaillé
                report_data = {
                    'Trouble': ['Apnée du Sommeil', 'Insomnie', 'Narcolepsie'],
                    'Détecté': [
                        'Oui' if disorder_results['apnee']['detected'] else 'Non',
                        'Oui' if disorder_results['insomnie']['detected'] else 'Non', 
                        'Oui' if disorder_results['narcolepsie']['detected'] else 'Non'
                    ],
                    'Sévérité': [
                        disorder_results['apnee']['severity'],
                        disorder_results['insomnie']['severity'],
                        disorder_results['narcolepsie']['severity']
                    ],
                    'Confiance': [
                        f"{disorder_results['apnee']['confidence']*100:.1f}%",
                        f"{disorder_results['insomnie']['confidence']*100:.1f}%",
                        f"{disorder_results['narcolepsie']['confidence']*100:.1f}%"
                    ],
                    'Détails': [
                        f"{disorder_results['apnee']['episodes']} épisodes",
                        f"{disorder_results['insomnie']['wake_periods']} réveils",
                        f"{disorder_results['narcolepsie']['rem_episodes']} REM"
                    ]
                }
                
                results_df = pd.DataFrame(report_data)
                
                col1, col2 = st.columns(2)
                with col1:
                    st.dataframe(results_df, use_container_width=True)
                
                with col2:
                    # Bouton de téléchargement du rapport
                    csv_report = results_df.to_csv(index=False)
                    st.download_button(
                        label="📥 Télécharger le rapport diagnostique",
                        data=csv_report,
                        file_name=f"diagnostic_sommeil_{uploaded_file.name.split('.')[0]}.csv" if 'uploaded_file' in locals() else "diagnostic_sommeil.csv",
                        mime="text/csv"
                    )
                
                st.success("✅ Analyse des troubles du sommeil terminée !")

else:
    st.warning("⚠️ Veuillez d'abord charger un fichier CSV pour accéder à la détection des troubles du sommeil.")

# Note importante
st.markdown("""
<div class="custom-card" style="border-left: 4px solid #ffa726;">
    <h4>⚠️ Avertissement Médical</h4>
    <p>Cette analyse est à des fins de recherche et d'information seulement. 
    Elle ne remplace pas un diagnostic médical professionnel. 
    Consultez toujours un médecin spécialiste du sommeil pour un diagnostic définitif.</p>
</div>
""", unsafe_allow_html=True)
# Footer
st.markdown("---")

from datetime import datetime, date
# Plotly retiré - utilisation de matplotlib seulement

# Import de ton analyseur (assure-toi que le fichier est dans le même dossier)
from sleep_analyzer import SleepDiaryAnalyzer, run_complete_analysis, load_sample_data

# CSS personnalisé pour améliorer l'apparence
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
        margin: 0.5rem 0;
    }
    .insight-box {
        background: #e8f4f8;
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #bee5eb;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def init_session_state():
    """Initialisation des variables de session"""
    if 'sleep_entries' not in st.session_state:
        st.session_state.sleep_entries = []
    if 'analysis_results' not in st.session_state:
        st.session_state.analysis_results = None
    if 'analyzer' not in st.session_state:
        st.session_state.analyzer = SleepDiaryAnalyzer()

def main():
    init_session_state()
    
    # En-tête principal
    st.markdown("""
    <div class="main-header">
        <h1>🌙 Analyseur de Journal de Sommeil</h1>
        <p>Analyse intelligente de vos nuits avec traitement du langage naturel</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar pour la navigation
    st.sidebar.title("🔧 Options")
    page = st.sidebar.selectbox(
        "Choisir une section",
        ["📝 Saisie des données", "📊 Analyse et résultats", "📈 Historique et tendances", "⚙️ Paramètres"]
    )
    
    if page == "📝 Saisie des données":
        show_data_input()
    elif page == "📊 Analyse et résultats":
        show_analysis_results()
    elif page == "📈 Historique et tendances":
        show_trends()
    elif page == "⚙️ Paramètres":
        show_settings()

def show_data_input():
    """Section de saisie des données"""
    st.markdown('<div class="section-header"><h3>📝 Saisie de votre journal de sommeil</h3></div>', unsafe_allow_html=True)
    
    # Tabs pour différents modes de saisie
    tab1, tab2, tab3 = st.tabs(["✍️ Saisie manuelle", "📄 Import fichier", "🎯 Données d'exemple"])
    
    with tab1:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("Décrivez votre nuit")
            
            # Date de la nuit
            sleep_date = st.date_input("Date de la nuit", value=date.today())
            
            # Zone de texte pour la description
            sleep_description = st.text_area(
                "Comment s'est passée votre nuit ?",
                placeholder="Exemple: J'ai mal dormi cette nuit, je me suis réveillé 3 fois vers 2h du matin. Je me sens fatigué ce matin...",
                height=150
            )
            
            # Boutons d'action
            col_btn1, col_btn2 = st.columns(2)
            with col_btn1:
                if st.button("➕ Ajouter cette entrée", type="primary"):
                    if sleep_description.strip():
                        entry = {
                            'date': sleep_date,
                            'description': sleep_description,
                            'timestamp': datetime.now()
                        }
                        st.session_state.sleep_entries.append(entry)
                        st.success("✅ Entrée ajoutée avec succès!")
                        st.rerun()
            
            with col_btn2:
                if st.button("🔍 Analyser cette entrée"):
                    if sleep_description.strip():
                        quick_analysis = st.session_state.analyzer.analyze_single_entry(sleep_description)
                        if quick_analysis:
                            # Store the analysis temporarily to show it outside the column context
                            st.session_state.temp_quick_analysis = quick_analysis
                            st.rerun()
        
        with col2:
            st.subheader("💡 Conseils de saisie")
            st.info("""
            **Pour une meilleure analyse, mentionnez :**
            - Votre ressenti au réveil
            - Nombre de réveils nocturnes  
            - Durée approximative de sommeil
            - Facteurs perturbateurs
            - État émotionnel
            
            **Exemples :**
            - "Je me suis couché à 23h et levé à 7h"
            - "Réveillé 2 fois dans la nuit"
            - "Je me sens fatigué/reposé"
            - "Stress à cause du travail"
            """)
        
        # Show quick analysis results outside of column context
        if hasattr(st.session_state, 'temp_quick_analysis'):
            show_quick_analysis(st.session_state.temp_quick_analysis)
            # Clear the temporary analysis after showing
            del st.session_state.temp_quick_analysis
    
    with tab2:
        st.subheader("📄 Importer un fichier")
        uploaded_file = st.file_uploader(
            "Choisir un fichier CSV",
            type=['csv', 'txt'],
            help="Le fichier doit contenir une colonne 'description' avec vos entrées de sommeil"
        )
        
        if uploaded_file:
            try:
                df = pd.read_csv(uploaded_file)
                st.dataframe(df.head())
                
                if 'description' in df.columns:
                    if st.button("📥 Importer ces données"):
                        for _, row in df.iterrows():
                            entry = {
                                'date': row.get('date', date.today()),
                                'description': row['description'],
                                'timestamp': datetime.now()
                            }
                            st.session_state.sleep_entries.append(entry)
                        st.success(f"✅ {len(df)} entrées importées!")
                        st.rerun()
                else:
                    st.error("❌ Le fichier doit contenir une colonne 'description'")
            except Exception as e:
                st.error(f"❌ Erreur lors de la lecture du fichier: {e}")
    
    with tab3:
        st.subheader("🎯 Données d'exemple")
        st.info("Utilisez ces données pour tester l'analyseur")
        
        if st.button("📥 Charger les données d'exemple"):
            sample_data = load_sample_data()
            for i, desc in enumerate(sample_data):
                entry = {
                    'date': date.today(),
                    'description': desc,
                    'timestamp': datetime.now()
                }
                st.session_state.sleep_entries.append(entry)
            st.success(f"✅ {len(sample_data)} entrées d'exemple ajoutées!")
            st.rerun()
    
    # Affichage des entrées actuelles
    if st.session_state.sleep_entries:
        st.subheader("📋 Vos entrées actuelles")
        
        # Tableau des entrées avec possibilité de suppression
        for i, entry in enumerate(st.session_state.sleep_entries):
            with st.expander(f"📅 {entry['date']} - Entrée #{i+1}"):
                st.write(f"**Description:** {entry['description']}")
                st.write(f"**Ajoutée le:** {entry['timestamp'].strftime('%d/%m/%Y %H:%M')}")
                
                if st.button(f"🗑️ Supprimer", key=f"del_{i}"):
                    st.session_state.sleep_entries.pop(i)
                    st.rerun()

def show_quick_analysis(analysis):
    """Affichage rapide d'une analyse - Now properly structured to avoid nested columns"""
    st.subheader("🔍 Analyse rapide")
    
    # Create columns at the top level (not nested)
    col1, col2, col3 = st.columns(3)
    
    with col1:
        sentiment_color = "green" if analysis['sentiment_compound'] > 0 else "red"
        st.markdown(f"""
        <div class="metric-card">
            <h4>😊 Sentiment</h4>
            <h2 style="color: {sentiment_color}">{analysis['sentiment_compound']:.2f}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        quality_color = {"Bonne qualité": "green", "Qualité moyenne": "orange", "Mauvaise qualité": "red"}
        st.markdown(f"""
        <div class="metric-card">
            <h4>🛌 Qualité</h4>
            <h3 style="color: {quality_color.get(analysis['qualite_sommeil'], 'gray')}">{analysis['qualite_sommeil']}</h3>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        score_color = "green" if analysis['score_global'] > 0 else "red"
        st.markdown(f"""
        <div class="metric-card">
            <h4>📊 Score Global</h4>
            <h2 style="color: {score_color}">{analysis['score_global']:.2f}</h2>
        </div>
        """, unsafe_allow_html=True)
    
    if analysis['problemes_detectes']:
        st.warning(f"⚠️ **Problèmes détectés:** {', '.join(analysis['problemes_detectes'])}")

def show_analysis_results():
    """Section des résultats d'analyse"""
    st.header("📊 Analyse et résultats")
    
    if not st.session_state.sleep_entries:
        st.warning("⚠️ Aucune entrée de sommeil trouvée. Ajoutez des données dans la section 'Saisie des données'.")
        return
    
    # Bouton pour lancer l'analyse complète
    if st.button("🚀 Lancer l'analyse complète", type="primary"):
        with st.spinner("🔄 Analyse en cours..."):
            descriptions = [entry['description'] for entry in st.session_state.sleep_entries]
            results_df, insights, fig = run_complete_analysis(descriptions)
            st.session_state.analysis_results = {
                'dataframe': results_df,
                'insights': insights,
                'figure': fig
            }
        st.success("✅ Analyse terminée!")
        st.rerun()
    
    # Affichage des résultats si disponibles
    if st.session_state.analysis_results:
        results = st.session_state.analysis_results
        df = results['dataframe']
        insights = results['insights']
        
        # Métriques principales
        st.subheader("📈 Métriques principales")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("📝 Entrées analysées", insights['total_entries'])
        
        with col2:
            sentiment_delta = insights['avg_sentiment']
            st.metric("😊 Sentiment moyen", f"{sentiment_delta:.3f}", delta=f"{sentiment_delta:.3f}")
        
        with col3:
            if insights.get('avg_sleep_hours'):
                st.metric("⏰ Heures moy.", f"{insights['avg_sleep_hours']:.1f}h")
            else:
                st.metric("⏰ Heures moy.", "N/A")
        
        with col4:
            if insights.get('avg_wake_ups'):
                st.metric("🔄 Réveils moy.", f"{insights['avg_wake_ups']:.1f}")
            else:
                st.metric("🔄 Réveils moy.", "N/A")
        
        # Graphiques avec Matplotlib
        st.subheader("📊 Visualisations")
        
        # Distribution de la qualité du sommeil
        col1, col2 = st.columns(2)
        
        with col1:
            quality_dist = pd.Series(insights['quality_distribution'])
            fig_pie, ax_pie = plt.subplots(figsize=(8, 6))
            ax_pie.pie(quality_dist.values, labels=quality_dist.index, autopct='%1.1f%%')
            ax_pie.set_title("Distribution de la Qualité du Sommeil")
            st.pyplot(fig_pie)
            plt.close()
        
        with col2:
            # Évolution du sentiment
            fig_line, ax_line = plt.subplots(figsize=(8, 6))
            ax_line.plot(range(len(df)), df['sentiment_compound'], marker='o')
            ax_line.axhline(y=0, color='red', linestyle='--', alpha=0.7)
            ax_line.set_title("Évolution du Sentiment")
            ax_line.set_xlabel("Entrées")
            ax_line.set_ylabel("Score de Sentiment")
            ax_line.grid(True, alpha=0.3)
            st.pyplot(fig_line)
            plt.close()
        
        # Problèmes les plus fréquents
        if insights['most_common_issues']:
            st.subheader("⚠️ Problèmes les plus fréquents")
            issues_df = pd.DataFrame(list(insights['most_common_issues'].items()), 
                                   columns=['Problème', 'Fréquence'])
            fig_bar, ax_bar = plt.subplots(figsize=(10, 6))
            ax_bar.bar(issues_df['Problème'], issues_df['Fréquence'])
            ax_bar.set_title("Fréquence des Problèmes Détectés")
            ax_bar.set_xlabel("Problème")
            ax_bar.set_ylabel("Fréquence")
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            st.pyplot(fig_bar)
            plt.close()
        
        # Tableau détaillé
        st.subheader("📋 Résultats détaillés")
        
        # Filtrages
        col1, col2 = st.columns(2)
        with col1:
            quality_filter = st.multiselect(
                "Filtrer par qualité",
                options=df['qualite_sommeil'].unique(),
                default=df['qualite_sommeil'].unique()
            )
        
        with col2:
            sentiment_min = st.slider(
                "Sentiment minimum",
                min_value=float(df['sentiment_compound'].min()),
                max_value=float(df['sentiment_compound'].max()),
                value=float(df['sentiment_compound'].min())
            )
        
        # Application des filtres
        filtered_df = df[
            (df['qualite_sommeil'].isin(quality_filter)) &
            (df['sentiment_compound'] >= sentiment_min)
        ]
        
        st.dataframe(filtered_df, use_container_width=True)
        
        # Bouton de téléchargement
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            label="📥 Télécharger les résultats (CSV)",
            data=csv,
            file_name=f"analyse_sommeil_{datetime.now().strftime('%Y%m%d_%H%M')}.csv",
            mime="text/csv"
        )

def show_trends():
    """Section des tendances et historique"""
    st.header("📈 Historique et tendances")
    
    if not st.session_state.analysis_results:
        st.warning("⚠️ Lancez d'abord une analyse complète dans la section 'Analyse et résultats'.")
        return
    
    df = st.session_state.analysis_results['dataframe']
    
    # Analyse temporelle si on a les dates
    if st.session_state.sleep_entries:
        # Ajouter les dates aux résultats
        dates = [entry['date'] for entry in st.session_state.sleep_entries[-len(df):]]
        df_with_dates = df.copy()
        df_with_dates['date'] = dates
        
        # Graphique d'évolution temporelle
        fig_temporal, ax_temporal = plt.subplots(figsize=(12, 6))
        ax_temporal.plot(df_with_dates['date'], df_with_dates['sentiment_compound'], marker='o')
        ax_temporal.set_title("Évolution du sentiment dans le temps")
        ax_temporal.set_xlabel("Date")
        ax_temporal.set_ylabel("Score de Sentiment")
        ax_temporal.grid(True, alpha=0.3)
        plt.xticks(rotation=45)
        plt.tight_layout()
        st.pyplot(fig_temporal)
        plt.close()
        
        # Analyse par jour de la semaine
        df_with_dates['day_of_week'] = pd.to_datetime(df_with_dates['date']).dt.day_name()
        daily_avg = df_with_dates.groupby('day_of_week')['sentiment_compound'].mean().reset_index()
        
        fig_weekly, ax_weekly = plt.subplots(figsize=(10, 6))
        ax_weekly.bar(daily_avg['day_of_week'], daily_avg['sentiment_compound'])
        ax_weekly.set_title("Sentiment moyen par jour de la semaine")
        ax_weekly.set_xlabel("Jour de la semaine")
        ax_weekly.set_ylabel("Score de Sentiment")
        plt.xticks(rotation=45)
        plt.tight_layout()
        st.pyplot(fig_weekly)
        plt.close()

def show_settings():
    """Section des paramètres"""
    st.header("⚙️ Paramètres")
    
    st.subheader("🗑️ Gestion des données")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🗑️ Effacer toutes les entrées", type="secondary"):
            st.session_state.sleep_entries = []
            st.success("✅ Toutes les entrées ont été supprimées")
            st.rerun()
    
    with col2:
        if st.button("🔄 Réinitialiser l'analyse"):
            st.session_state.analysis_results = None
            st.success("✅ Analyse réinitialisée")
            st.rerun()
    
    st.subheader("📊 Statistiques de session")
    st.write(f"- Nombre d'entrées: {len(st.session_state.sleep_entries)}")
    st.write(f"- Analyse disponible: {'Oui' if st.session_state.analysis_results else 'Non'}")
    
    st.subheader("ℹ️ À propos")
    st.info("""
    **Analyseur de Journal de Sommeil v1.0**
    
    Cet outil utilise des techniques de traitement du langage naturel (NLP) pour analyser vos descriptions de sommeil :
    - Analyse de sentiment avec VADER
    - Extraction d'entités temporelles
    - Classification automatique de la qualité
    - Détection de problèmes de sommeil
    
    Développé avec Streamlit et NLTK.
    """)

if __name__ == "__main__":
    main()